<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post("login", "AuthController@login");
Route::post("register", "AuthController@register");

Route::group(['middleware' => 'auth:sanctum'], function () {
    Route::post("logout", "AuthController@logout");
    // Users
    Route::get('users', 'UserController@index');
    Route::get('users/{id}', 'UserController@show');
    Route::patch('users/{id}', 'UserController@update');
    Route::patch('users/{id}/change-password', 'UserController@updatePassword');
    Route::delete('users/{id}', 'UserController@destroy');

    // Sites
    Route::get("sites", "SiteController@index");                // replace
    Route::post("sites", "SiteController@store");               // replace
    Route::get("sites/{id}", "SiteController@show");            // replace
    Route::patch("sites/{id}", "SiteController@update");        // replace
    Route::delete('sites/{id}', 'SiteController@destroy');      // replace

    // Operational entity
    Route::get("operating-entities", "OperatingEntityController@index");
    Route::post("operating-entities", "OperatingEntityController@store");
    Route::get("operating-entities/{id}", "OperatingEntityController@show");
    Route::patch("operating-entities/{id}", "OperatingEntityController@update");
    Route::delete("operating-entities/{id}", "OperatingEntityController@destroy");

    // Projects
    Route::get("projects", "ProjectController@index");
    Route::post("sites/{id}/projects", "ProjectController@store");  // replace
    Route::post("operating-entities/{id}/projects", "ProjectController@store");
    Route::get("projects/{id}", "ProjectController@show");
    Route::patch("projects/{id}", "ProjectController@update");
    Route::delete("projects/{id}", "ProjectController@destroy");

    // Site Projects
    Route::get("sites/{id}/projects", "SiteProjectController@index");                                      // replace
    Route::get("sites/{id}/projects-with-initiatives", "SiteProjectController@indexWithInitiatives");      // replace

    // Operating entity projects
    Route::get("operating-entities/{id}/projects", "OperatingEntityProjectController@index");
    Route::get("operating-entities/{id}/projects-with-changes", "OperatingEntityProjectController@indexWithChanges");

    // Site Impacts
    Route::get("sites/{id}/impacts", "SiteImpactController@index");     // replace

    // Operating entity impacts
    Route::get("operating-entities/{id}/impacts", "OperatingEntityImpactController@index");

    // Initiatives
    Route::get("initiatives", "InitiativeController@index");                    // replace
    Route::post("projects/{id}/initiatives", "InitiativeController@store");     // replace
    Route::get("initiatives/{id}", "InitiativeController@show");                // replace
    Route::patch("initiatives/{id}", "InitiativeController@update");            // replace
    Route::delete("initiatives/{id}", "InitiativeController@destroy");          // replace

    // Changes
    Route::get("changes", "ChangeController@index");
    Route::post("projects/{id}/changes", "ChangeController@store");
    Route::get("changes/{id}", "ChangeController@show");
    Route::patch("changes{id}", "ChangeController@update");
    Route::delete("change/{id}", "ChangeController@destroy");

    // Project Initiatives
    Route::get("projects/{id}/initiatives", "ProjectInitiativeController@index");   // replace

    // Project changes
    Route::get("projects/{id}/changes", "ProjectChangeController@index");

    // Corrective Actions
    Route::get("corrective-actions", "CorrectiveActionController@index");
    Route::post("corrective-actions", "CorrectiveActionController@store");
    Route::get("corrective-actions/{id}", "CorrectiveActionController@show");
    Route::patch("corrective-actions/{id}", "CorrectiveActionController@update");
    Route::delete("corrective-actions/{id}", "CorrectiveActionController@destroy");

    // Site Corrective Actions
    Route::get("sites/{id}/corrective-actions", "SiteCorrectiveActionController@index");            // replace

    // Operating Entity Corrective Actions
    Route::get("operating-entities/{id}/corrective-actions", "OperatingEntityCorrectiveActionController@index");

    // Initiative Corrective Actions
    Route::get("initiatives/{id}/corrective-actions", "InitiativeCorrectiveActionController@index"); // replace

    // Change Corrective Actions
    Route::get("changes/{id}/corrective-actions", "ChangeCorrectiveActionController@index");

    // Corrective Action Types
    Route::get("corrective-action-type", "CorrectiveActionTypeController@index");
    Route::post("corrective-action-types", "CorrectiveActionTypeController@store");
    Route::get("corrective-action-types/{id}", "CorrectiveActionTypeController@show");
    Route::patch("corrective-action-types/{id}", "CorrectiveActionTypeController@update");
    Route::delete("corrective-action-types/{id}", "CorrectiveActionTypeController@destroy");

    // Impacts
    Route::get("impacts", "ImpactController@index");
    Route::post("impacts", "ImpactController@store");
    Route::get("impacts/{id}", "ImpactController@show");
    Route::patch("impacts/{id}", "ImpactController@update");
    Route::delete("impacts/{id}", "ImpactController@destroy");

    // Initiative Impacts
    Route::get("initiatives/{id}/impacts", "InitiativeImpactController@index");     // replace

    // Change Impacts
    Route::get("changes/{id}/impacts", "ChangeImpactController@index");

    // Communities
    Route::get("sites/{id}/communities", "CommunityController@index");
    Route::get("sites/{id}/communities-with-members", "CommunityController@indexWithMembers");
    Route::get("sites/{id}/communities-with-personas", "CommunityController@indexWithPersonas");
    Route::post("sites/{id}/communities", "CommunityController@store");
    Route::get("communities/{id}", "CommunityController@show");
    Route::patch("communities/{id}", "CommunityController@update");
    Route::delete("communities/{id}", "CommunityController@destroy");

    Route::get("communities/{id}/personas", "CommunityController@indexPersonas");

    // Personas
    Route::get("personas", "PersonaController@index");
    Route::post("personas", "PersonaController@store");
    Route::get("personas/{id}", "PersonaController@show");
    Route::patch("personas/{id}", "PersonaController@update");
    Route::delete("personas/{id}", "PersonaController@destroy");

    Route::post("communities/{communityId}/add-persona/{personaId}", "CommunityController@attachPersona");
    Route::delete("communities/{communityId}/remove-persona/{personaId}", "CommunityController@detachPersona");

    // Project Types
    Route::get("project-types", "ProjectTypeController@index");

    // Project Categories
    Route::get("project-categories", "ProjectCategoryController@index");

    // Change Aspects
    Route::get("change-aspects", "ChangeAspectController@index");
    Route::post("change-aspects", "ChangeAspectController@store");
    Route::get("change-aspects/{id}", "ChangeAspectController@show");
    Route::patch("change-aspects/{id}", "ChangeAspectController@update");
    Route::delete("change-aspects/{id}", "ChangeAspectController@destroy");

    // Change Journeys
    Route::get("sites/{id}/change-journeys", "ChangeJourneyController@siteIndex");              // replace

    // Mutliple Project Initiatives
    Route::get("multiple-projects/initiatives", "MultipleProjectInitiativeController@index");   // replace

    // Multiple Project Changes
    Route::get("multiple-projects/changes", "MultipleProjectChangeController@index");

    // Multiple Project Impacts
    Route::get("sites/{id}/multiple-projects/impacts", "MultipleProjectImpactController@index");    // replace

    // Multiple Project Impacts
    Route::get("operating-entities/{id}/multiple-projects/impacts", "MultipleProjectImpactController@index");

    // Multiple Initiative Impacts
    Route::get("/sites/{id}/multiple-initiatives/impacts", "MultipleInitiativeImpactController@index"); // replace

    // Multiple changes impacts
    Route::get("operatig-entities/{id}/multiple-changes/impacts", "MultipleChangeImpactController@index");

    // Impact Summation
    Route::get("/sites/{id}/impacts-summation", "SiteImpactController@sumIndex");                   // replace

    // Impact Summation
    Route::get("operating-entities/{id}/impacts-summation", "OperatingEntityImpactController@sumIndex");
});