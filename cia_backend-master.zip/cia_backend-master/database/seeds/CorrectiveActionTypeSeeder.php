<?php

use Illuminate\Database\Seeder;

class CorrectiveActionTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
