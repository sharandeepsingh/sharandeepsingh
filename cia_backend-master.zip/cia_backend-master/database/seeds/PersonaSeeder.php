<?php

use App\Persona;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PersonaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Persona::create([
            'name' => 'Managers',
            'color' => '#42A5F5'
        ]);

        Persona::create([
            'name' => 'Miners',
            'color' => '#FFA726'
        ]);

        Persona::create([
            'name' => 'Engineers',
            'color' => '#66BB6A'
        ]);
    }
}