<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ChangeAspectSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('change_aspects')->insert([
            ['name' => 'Processes'],
            ['name' => 'Policies'],
            ['name' => 'Skills Requirement'],
            ['name' => 'Organisational Structure'],
            ['name' => 'Roles and Responsibilities'],
            ['name' => 'Workload'],
            ['name' => 'Rewards and Recognition'],
            ['name' => 'Culture'],
            ['name' => 'Tools'],
        ]);
    }
}