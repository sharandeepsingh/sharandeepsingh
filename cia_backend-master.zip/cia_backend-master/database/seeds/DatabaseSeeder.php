<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UserSeeder::class);
        $this->call(UserSeeder::class);
        $this->call(SiteSeeder::class);
        $this->call(ChangeAspectSeeder::class);
        $this->call(PersonaSeeder::class);
        $this->call(ProjectCategorySeeder::class);
        $this->call(ProjectTypeSeeder::class);
    }
}