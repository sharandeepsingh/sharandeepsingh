<?php

use App\Site;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SiteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Site::create(
            ['name' => 'Rosh Pinah'],
        );

        Site::create(
            ['name' => 'Perkoa'],
        );

        Site::create(
            ['name' => 'Santander'],
        );
    }
}