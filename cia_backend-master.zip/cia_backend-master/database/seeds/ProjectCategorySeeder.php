<?php

use App\ProjectCategory;
use Illuminate\Database\Seeder;

class ProjectCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {;
        ProjectCategory::create([
            'name' => 'Technology'
        ]);

        ProjectCategory::create([
            'name' => 'People'
        ]);

        ProjectCategory::create([
            'name' => 'Equipment'
        ]);
    }
}