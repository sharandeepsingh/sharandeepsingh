<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\Community;

$factory->define(Community::class, function (Faker $faker) {
    return [
        //
    ];
});
