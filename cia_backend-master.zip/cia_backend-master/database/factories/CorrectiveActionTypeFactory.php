<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\CorrectiveActionType;

$factory->define(CorrectiveActionType::class, function (Faker $faker) {
    return [
        //
    ];
});
