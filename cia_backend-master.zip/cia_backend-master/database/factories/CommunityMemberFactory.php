<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\CommunityMember;

$factory->define(CommunityMember::class, function (Faker $faker) {
    return [
        //
    ];
});
