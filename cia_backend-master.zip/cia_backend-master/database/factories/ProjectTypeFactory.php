<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\ProjectType;

$factory->define(ProjectType::class, function (Faker $faker) {
    return [
        //
    ];
});
