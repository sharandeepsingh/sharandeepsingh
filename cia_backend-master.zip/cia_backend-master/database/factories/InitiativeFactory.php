<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\Initiative;

$factory->define(Initiative::class, function (Faker $faker) {
    return [
        //
    ];
});
