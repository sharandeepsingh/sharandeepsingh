<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\Persona;

$factory->define(Persona::class, function (Faker $faker) {
    return [
        //
    ];
});
