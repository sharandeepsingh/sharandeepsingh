<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\ChangeJourney;

$factory->define(ChangeJourney::class, function (Faker $faker) {
    return [
        //
    ];
});
