<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCorrectiveActionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('corrective_actions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->text('description');
            $table->unsignedBigInteger('corrective_action_type_id');
            $table->unsignedBigInteger('owner');
            $table->unsignedBigInteger('change_aspect_id')->nullable();
            $table->uuid('change_journey_id')->nullable();
            $table->integer('step_in_chain')->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->timestamps();

            $table->foreign('corrective_action_type_id')
                ->references('id')
                ->on('corrective_action_types');

            $table->foreign('owner')
                ->references('id')
                ->on('users');

            $table->foreign('change_aspect_id')
                ->references('id')
                ->on('change_aspects');
        });

        Schema::create('corrective_action_initiative', function (Blueprint $table) {
            $table->primary(['corrective_action_id', 'initiative_id'], 'id');
            $table->uuid('corrective_action_id');
            $table->uuid('initiative_id');

            $table->foreign('corrective_action_id')
                ->references('id')
                ->on('corrective_actions')
                ->onDelete('cascade');

            $table->foreign('initiative_id')
                ->references('id')
                ->on('initiatives')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('corrective_actions');
    }
}