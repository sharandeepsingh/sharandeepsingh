<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateImpactsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('impacts', function (Blueprint $table) {
            $table->id();
            $table->uuid('initiative_id');
            $table->uuid('persona_id');
            $table->uuid('community_id');
            $table->unsignedBigInteger('change_aspect_id');
            $table->integer('severity');
            $table->timestamps();

            $table->foreign('initiative_id')
                ->references('id')
                ->on('initiatives')
                ->onDelete('cascade');

            $table->foreign('persona_id')
                ->references('id')
                ->on('personas')
                ->onDelete('cascade');

            $table->foreign('change_aspect_id')
                ->references('id')
                ->on('change_aspects');

            $table->foreign('community_id')
                ->references('id')
                ->on('communities')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('impacts');
    }
}