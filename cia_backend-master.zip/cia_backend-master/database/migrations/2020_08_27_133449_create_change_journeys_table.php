<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateChangeJourneysTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('change_journeys', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->unsignedBigInteger('change_aspect_id');
            $table->string('level');
            $table->uuid('site_id');
            $table->timestamps();

            $table->foreign('change_aspect_id')
                ->references('id')
                ->on('change_aspects');

            $table->foreign('site_id')
                ->references('id')
                ->on('sites');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('change_journeys');
    }
}