<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StakeholderRole extends Model
{
    use \App\Http\Traits\UsesUuid;

    protected $fillable = [
        'name', 'stakeholder_group_id', 'number_of_people'
    ];

    public function stakeholderGroup()
    {
        return $this->belongsTo(\App\StakeholderGroup::class);
    }
}