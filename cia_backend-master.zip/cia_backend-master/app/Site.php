<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Site extends Model
{
    use \App\Http\Traits\UsesUuid;

    protected $fillable = [
        'name'
    ];

    public function projects()
    {
        return $this->hasMany(\App\Project::class);
    }

    public function initiatives()
    {
        return $this->hasManyThrough(\App\Initiative::class, \App\Project::class);
    }

    public function stakeholderGroups()
    {
        return $this->hasMany(\App\StakeholderGroup::class);
    }
}