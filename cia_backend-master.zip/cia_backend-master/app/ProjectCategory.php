<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProjectCategory extends Model
{
    protected $fillable = [
        'name'
    ];

    public function projectTypes()
    {
        return $this->hasMany(\App\ProjectType::class);
    }

    public function projects()
    {
        return $this->hasManyThrough('App\Project', 'App\ProjectType');
    }
}