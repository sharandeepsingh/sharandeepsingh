<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Persona extends Model
{
    use \App\Http\Traits\UsesUuid;

    protected $fillable = [
        'name', 'color'
    ];

    public function communities()
    {
        return $this->belongsToMany('App\Community');
    }
}