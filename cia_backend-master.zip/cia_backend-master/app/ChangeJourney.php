<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChangeJourney extends Model
{
    use \App\Http\Traits\UsesUuid;

    protected $hidden = [
        'change_aspect_id'
    ];

    protected $fillable = [
        'site_id', 'change_aspect_id', 'level'
    ];

    public function changeAspect()
    {
        return $this->belongsTo(ChangeAspect::class);
    }

    public function site()
    {
        return $this->belongsTo(Site::class);
    }

    // SCOPES
    public function scopeWithChangeAspect($query)
    {
        return $query->with('changeAspect');
    }
}