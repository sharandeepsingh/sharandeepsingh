<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use \App\Http\Traits\UsesUuid;

    protected $fillable = [
        'name', 'site_id', 'active', 'project_type_id'
    ];

    public function site()
    {
        return $this->belongsTo(\App\Site::class);
    }

    public function initiatives()
    {
        return $this->hasMany(\App\Initiative::class);
    }
}