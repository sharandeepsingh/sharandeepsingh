<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CorrectiveAction extends Model
{
    use \App\Http\Traits\UsesUuid;

    protected $fillable = [
        'name', 'description', 'corrective_action_type_id',
        'start_date', 'end_date'
    ];

    public function correctiveActionType()
    {
        return $this->belongsTo(\App\CorrectiveActionType::class);
    }

    public function owner()
    {
        return $this->belongsTo(\App\User::class, 'owner');
    }

    public function initiatives()
    {
        return $this->belongsToMany(
            \App\Initiative::class,
            'corrective_action_initiative'
        );
    }
}