<?php

namespace App\Listeners;

use App\Helpers\ChangeJourneyHelper;
use App\Events\ImpactSaved;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class CreateChangeJourneys
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  ImpactSaved  $event
     * @return void
     */
    public function handle(ImpactSaved $event)
    {
        ChangeJourneyHelper::createChangeJourneys($event->site);
    }
}