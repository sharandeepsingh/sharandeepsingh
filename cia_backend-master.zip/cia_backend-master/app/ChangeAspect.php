<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChangeAspect extends Model
{
    protected $fillable = [
        'name'
    ];
}
