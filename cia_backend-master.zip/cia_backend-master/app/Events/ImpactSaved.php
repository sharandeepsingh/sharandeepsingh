<?php

namespace App\Events;

use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ImpactSaved
{
    use Dispatchable, SerializesModels;

    public $site;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($site)
    {
        $this->site = $site;
    }
}