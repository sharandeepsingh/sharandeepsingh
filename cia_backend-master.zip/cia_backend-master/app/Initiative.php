<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Initiative extends Model
{
    use \App\Http\Traits\UsesUuid;

    protected $fillable = [
        'name', 'project_id', 'start_date', 'end_date',
        'owner_id'
    ];

    public function project()
    {
        return $this->belongsTo(\App\Project::class);
    }

    public function impacts()
    {
        return $this->hasMany(\App\Impact::class);
    }

    public function correctiveActions()
    {
        return $this->belongsToMany(
            \App\CorrectiveAction::class,
            'corrective_action_initiative'
        );
    }
}