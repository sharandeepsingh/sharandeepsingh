<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Community extends Model
{
    use \App\Http\Traits\UsesUuid;

    protected $fillable = [
        'name', 'site_id', 'internal_external'
    ];

    public function site()
    {
        return $this->belongsTo(\App\Site::class);
    }

    public function personas()
    {
        return $this->belongsToMany('App\Persona')->withPivot('member_count');
    }
}