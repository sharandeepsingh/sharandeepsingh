<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StakeholderGroup extends Model
{
    use \App\Http\Traits\UsesUuid;

    protected $fillable = [
        'name', 'site_id', 'internal_external'
    ];

    public function site()
    {
        return $this->belongsTo(\App\Site::class);
    }

    public function stakeholderRoles()
    {
        return $this->hasMany(\App\StakeholderRole::class);
    }
}