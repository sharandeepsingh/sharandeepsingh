<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Impact extends Model
{
    protected $fillable = [
        'initiative_id', 'persona_id', 'community_id', 'change_aspect_id', 'severity'
    ];

    public function initiative()
    {
        return $this->belongsTo(\App\Initiative::class);
    }

    public function persona()
    {
        return $this->belongsTo(\App\Persona::class);
    }

    public function community()
    {
        return $this->belongsTo(\App\Community::class);
    }

    public function changeAspect()
    {
        return $this->belongsTo(\App\ChangeAspect::class);
    }
}