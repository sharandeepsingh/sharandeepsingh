<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Initiative;
use Illuminate\Http\Request;

class MultipleProjectInitiativeController extends Controller
{
    public function index(Request $request)
    {
        if ($request->has('project_ids')) {
            return Initiative::whereIn('project_id',
                $request->project_ids)->get();
        } else {
            return response([
                'error' => 'Request must have project_ids array field.'
            ], 400);
        }
    }
}
