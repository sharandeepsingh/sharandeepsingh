<?php

namespace App\Http\Controllers;

use App\Community;
use App\Http\Controllers\Controller;
use App\Http\Requests\AttachPersonaRequest;
use App\Http\Requests\CreateCommunityRequest;
use App\Persona;
use Faker\Provider\ar_JO\Person;
use Illuminate\Http\Request;

class CommunityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        return Community::where('site_id', $id)->get();
    }

    public function indexPersonas($id)
    {
        $community = Community::find($id);

        return $community->personas;
    }

    public function indexWithPersonas($id)
    {
        $communities = Community::where('site_id', $id)->with('personas')->get();

        foreach ($communities as $community) {
            foreach ($community->personas as $persona) {
                $persona->member_count = $persona->pivot->member_count;
            }
        }

        return $communities;
    }

    public function indexWithMembers($id)
    {
        return Community::where('site_id', $id)->with('members')->get();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreateCommunityRequest $request, $id)
    {
        $community = Community::create([
            'name' => $request->name,
            'site_id' => $id,
            'internal_external' => $request->internal_external ? 'external' : 'internal',
        ]);

        return response([
            'message' => 'Community created',
            'community' => $community
        ], 201);
    }

    public function attachPersona(AttachPersonaRequest $request, $communityId, $personaId)
    {
        $community = Community::find($communityId);

        $community->personas()->attach($personaId, ['member_count' => $request->member_count]);

        $persona = Persona::find($personaId);

        return response([
            'message' => 'Persona successfully added to community.',
            'community' => $community,
            'persona' => $persona
        ], 200);
    }

    public function detachPersona($communityId, $personaId)
    {
        $community = Community::find($communityId);

        $community->personas()->detach($personaId);

        $persona = Persona::find($personaId);

        return response([
            'message' => 'Persona detached from community.',
            'community' => $community,
            'persona' => $persona
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Community  $community
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Community::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Community  $community
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $community = Community::find($id)
            ->update($request->toArray());

        return response([
            'message' => 'Community updated.',
            'community' => $community
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Community  $community
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Community::find($id)->delete();
        return response([], 204);
    }
}