<?php

namespace App\Http\Controllers;

use App\Project;
use App\Http\Controllers\Controller;
use App\Http\Requests\CreateProjectRequest;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Project::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($id, CreateProjectRequest $request)
    {
        $project = Project::create([
            'site_id' => $id,
            'name' => $request->project_name,
            'project_type_id' => $request->project_type_id,
            'active' => $request->active
        ]);

        return response([
            'message' => 'Project created.',
            'project' => $project
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Project::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $project = Project::find($id)
            ->update($request->toArray());

        return response([
            'message' => 'Project updated.',
            'project' => $project
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Project::find($id)->delete();

        return response([
            'message' => 'Project deleted.'
        ], 204);
    }
}