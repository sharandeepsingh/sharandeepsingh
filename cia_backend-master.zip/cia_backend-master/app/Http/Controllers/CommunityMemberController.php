<?php

namespace App\Http\Controllers;

use App\Community;
use App\CommunityMember;
use App\Http\Controllers\Controller;
use App\Http\Requests\CreateCommunityMemberRequest;
use Illuminate\Http\Request;

class CommunityMemberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        return CommunityMember::where('community_id', $id)->with('persona')->get();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreateCommunityMemberRequest $request, $id)
    {
        $communityMember = CommunityMember::create([
            'name' => $request->name,
            'community_id' => $id,
            'persona_id' => $request->persona_id,
            'number_of_people' => $request->number_of_people
        ]);

        return response([
            'message' => 'Community member created.',
            'communityMember' => $communityMember
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CommunityMember  $communityMember
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return CommunityMember::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CommunityMember  $communityMember
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $communityMember = CommunityMember::find($id)
            ->update($request->toArray());

        return response([
            'message' => 'Community member updated.',
            'communityMember' => $communityMember
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CommunityMember  $communityMember
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        CommunityMember::find($id)->delete();
        return response([], 204);
    }
}