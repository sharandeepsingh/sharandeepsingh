<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\StakeholderGroup;
use Illuminate\Http\Request;

class StakeholderGroupStakeholderRoleController extends Controller
{
    public function index($id)
    {
        return StakeholderGroup::find($id)->stakeholderRoles;
    }
}
