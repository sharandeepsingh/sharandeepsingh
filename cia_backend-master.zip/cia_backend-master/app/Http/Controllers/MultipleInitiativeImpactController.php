<?php

namespace App\Http\Controllers;

use App\Helpers\ImpactHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\MultipleInitiativeImpactsRequest;
use Illuminate\Http\Request;

class MultipleInitiativeImpactController extends Controller
{
    public function index($id, MultipleInitiativeImpactsRequest $request)
    {
        return ImpactHelper::getMultipleInitiativeImpactsFromRequest(
            $id,
            $request
        );
    }
}