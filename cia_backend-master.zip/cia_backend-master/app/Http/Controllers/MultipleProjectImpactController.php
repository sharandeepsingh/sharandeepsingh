<?php

namespace App\Http\Controllers;

use App\Helpers\ImpactHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\MultipleProjectImpactsRequest;
use Illuminate\Http\Request;

class MultipleProjectImpactController extends Controller
{
    public function index($id, MultipleProjectImpactsRequest $request)
    {
        return ImpactHelper::getMultipleProjectImpactsFromRequest(
            $id,
            $request
        );
    }
}