<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateStakeholderGroupRequest;
use App\Site;
use App\StakeholderGroup;
use Illuminate\Http\Request;

class SiteStakeholderGroupController extends Controller
{
    public function index($id)
    {
        return Site::find($id)->stakeholderGroups;
    }

    public function indexWithStakeholderRoles($id)
    {
        return StakeholderGroup::where('site_id', $id)->with('stakeholderRoles')->get();
    }
}
