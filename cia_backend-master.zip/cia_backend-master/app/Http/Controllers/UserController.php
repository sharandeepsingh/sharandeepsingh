<?php

namespace App\Http\Controllers;

use App\Helpers\ResponseHelper;
use App\Helpers\UserHelper;
use App\Http\Requests\UpdatePasswordRequest;
use App\Http\Requests\UpdateUserRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * Index users
     *
     * @return User $user
     *
     */
    public function index()
    {
        // check if this user is an admin
        // return the list of users excluding the first one
        if (auth()->user()->is_admin) {
            return User::where('id', '<>', 1)->get();
        } else {
            return ResponseHelper::notAuthorizedResponse();
        }
    }

    /**
     * show a user
     *
     * @param mixed $id
     * @return User $user
     */
    public function show($id)
    {
        if (auth()->user()->is_admin || auth()->user()->id == $id) {
            return User::find($id);
        } else {
            return ResponseHelper::notAuthorizedResponse();
        }
    }

    /**
     * update an existing user
     *
     * @param mixed $id
     * @param Request $request
     */
    public function update($id, UpdateUserRequest $request)
    {
        return UserHelper::updateUser(
            User::find($id),
            $request
        );
    }

    /**
     * update a User's password
     *
     * @param [type] $id
     * @param UpdatePasswordRequest $request
     * @return void
     */
    public function updatePassword($id, UpdatePasswordRequest $request)
    {
        return UserHelper::updateUserPassword(
            User::find($id),
            $request->new_password,
            $request->old_password
        );
    }

    /**
     * Delete a user object
     *
     * @param $id
     * @return void
     */
    public function destroy($id)
    {
        return UserHelper::deleteUser(User::find($id));
    }
}