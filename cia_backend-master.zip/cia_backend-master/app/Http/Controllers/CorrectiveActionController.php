<?php

namespace App\Http\Controllers;

use App\CorrectiveAction;
use App\Helpers\CorrectiveActionHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\CreateCorrectiveActionRequest;
use Illuminate\Http\Request;

class CorrectiveActionController extends Controller
{
    public function index()
    {
        return CorrectiveAction::all();
    }

    public function show($id)
    {
        return CorrectiveAction::find($id);
    }

    public function store(CreateCorrectiveActionRequest $request)
    {
        return CorrectiveActionHelper::handleCreateRequest($request);
    }

    public static function update($id, Request $request)
    {
        $correctiveAction = CorrectiveAction::find($id);
        $correctiveAction->update($request->toArray());
        return $correctiveAction;
    }

    public function destroy($id)
    {
        CorrectiveAction::find($id)->delete();
        return response([], 204);
    }
}
