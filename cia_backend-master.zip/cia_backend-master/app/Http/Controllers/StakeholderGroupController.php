<?php

namespace App\Http\Controllers;

use App\StakeholderGroup;
use App\Http\Controllers\Controller;
use App\Http\Requests\CreateStakeholderGroupRequest;
use Illuminate\Http\Request;

class StakeholderGroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return StakeholderGroup::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreateStakeholderGroupRequest $request, $id)
    {
        $stakeholderGroup = StakeholderGroup::create([
            'name' => $request->name,
            'site_id' => $id,
            'internal_external' => $request->internal_external ? 'external' : 'internal',
        ]);

        return response([
            'message' => 'Stakeholder group created.',
            'stakeholderGroup' => $stakeholderGroup
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StakeholderGroup  $stakeholderGroup
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return StakeholderGroup::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StakeholderGroup  $stakeholderGroup
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $stakeholderGroup = StakeholderGroup::find($id)
            ->update($request->toArray());

        return response([
            'message' => 'Stakeholder group updated.',
            'stakeholderGroup' => $stakeholderGroup
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StakeholderGroup  $stakeholderGroup
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        StakeholderGroup::find($id)->delete();
        return response([], 204);
    }
}