<?php

namespace App\Http\Controllers;

use App\CorrectiveAction;
use App\Http\Controllers\Controller;
use App\Initiative;
use Illuminate\Http\Request;

class InitiativeCorrectiveActionController extends Controller
{
    public function index($id)
    {
        return Initiative::where('id', $id)->with('correctiveActions')->get();
    }
}
