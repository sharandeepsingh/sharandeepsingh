<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Site;
use App\Project;
use Illuminate\Http\Request;

class SiteProjectController extends Controller
{
    public function index($id)
    {
        return Site::find($id)->projects;
    }

    public function indexWithInitiatives($id)
    {
        return Project::where('site_id', $id)->with('initiatives')->get();
    }
}