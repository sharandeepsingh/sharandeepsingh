<?php

namespace App\Http\Controllers;

use App\ChangeAspect;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ChangeAspectController extends Controller
{
    public function index()
    {
        return ChangeAspect::all();
    }
}