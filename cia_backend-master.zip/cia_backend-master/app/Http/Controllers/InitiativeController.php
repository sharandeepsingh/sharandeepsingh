<?php

namespace App\Http\Controllers;

use App\Helpers\InitiativeHelper;
use App\Initiative;
use App\Http\Controllers\Controller;
use App\Http\Requests\CreateInitiativeRequest;
use Illuminate\Http\Request;

class InitiativeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Initiative::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($id, CreateInitiativeRequest $request)
    {
        return InitiativeHelper::handleInitiativeCreate($id, $request);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Initiative  $initiative
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return InitiativeHelper::showInitiative(Initiative::find($id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Initiative  $initiative
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $initiative = Initiative::find($id);
        $initiative->update($request->toArray());
        return $initiative;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Initiative  $initiative
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Initiative::find($id)->delete();
        return response([
            'message' => 'Initiative deleted.'
        ], 204);
    }
}