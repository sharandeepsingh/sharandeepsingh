<?php

namespace App\Http\Controllers;

use App\StakeholderRole;
use App\Http\Controllers\Controller;
use App\Http\Requests\CreateStakeholderRoleRequest;
use Illuminate\Http\Request;

class StakeholderRoleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return StakeholderRole::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($id, CreateStakeholderRoleRequest $request)
    {
        $stakeholderRole = StakeholderRole::create([
            'name' => $request->name,
            'stakeholder_group_id' => $id,
            'number_of_people' => $request->number_of_people
        ]);

        return response([
            'message' => 'Stakeholder role created.',
            'stakeholderRole' => $stakeholderRole
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StakeholderRole  $stakeholderRole
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return StakeholderRole::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StakeholderRole  $stakeholderRole
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $stakeholderRole = StakeholderRole::find($id)
            ->update($request->toArray());

        return response([
            'message' => 'Stakeholder role updated.',
            'stakeholderRole' => $stakeholderRole
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StakeholderRole  $stakeholderRole
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        StakeholderRole::find($id)->delete();
        return response([], 204);
    }
}