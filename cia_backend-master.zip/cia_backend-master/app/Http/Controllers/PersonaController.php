<?php

namespace App\Http\Controllers;

use App\Persona;
use App\Http\Controllers\Controller;
use App\Http\Requests\CreatePersonaCommunityRequest;
use App\Http\Requests\CreatePersonaRequest;
use Illuminate\Http\Request;

class PersonaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Persona::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreatePersonaRequest $request)
    {
        $persona = Persona::create([
            'name' => $request->name,
            'color' => $request->color
        ]);

        return response([
            'message' => 'Persona created',
            'persona' => $persona
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Persona  $persona
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Persona::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Persona  $persona
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $persona = Persona::find($id)
            ->update($request->toArray());

        return response([
            'message' => 'Persona updated',
            'persona' => $persona
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Persona  $persona
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Persona::find($id)->delete();
        return response([], 204);
    }
}