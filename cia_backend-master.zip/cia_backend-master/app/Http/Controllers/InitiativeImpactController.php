<?php

namespace App\Http\Controllers;

use App\Helpers\InitiativeImpactHelper;
use App\Http\Controllers\Controller;
use App\Initiative;
use Illuminate\Http\Request;

class InitiativeImpactController extends Controller
{
    public function index($id)
    {
        return InitiativeImpactHelper::handleGetInitiativeImpacts(
            Initiative::find($id)
        );
    }
}
