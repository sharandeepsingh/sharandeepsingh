<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Project;
use Illuminate\Http\Request;

class ProjectInitiativeController extends Controller
{
    public function index($id)
    {
        return Project::find($id)->initiatives;
    }
}
