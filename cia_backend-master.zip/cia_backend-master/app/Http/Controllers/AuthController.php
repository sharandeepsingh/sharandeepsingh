<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Helpers\UserHelper;
use App\Helpers\AuthHelper;
use App\Http\Requests\RegisterRequest;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function login(LoginRequest $request)
    {
        $user = UserHelper::getUserObjectByEmail($request->email);
        
        if (AuthHelper::loginIsInvalid($user, $request->password)) {
            return AuthHelper::invalidCredentialsResponse();
        }
        
        $token = $user->createToken('user-token')->plainTextToken;
        
        return AuthHelper::successfulLoginResponse($user, $token);
    }

    public function register(RegisterRequest $request)
    {
        return UserHelper::createUser($request);
    }

    public function logout(Request $request)
    {
        return AuthHelper::handleLogout(request()->user());
    }
}
