<?php

namespace App\Http\Controllers;

use App\Helpers\ImpactHelper;
use App\Http\Controllers\Controller;
use App\Impact;
use Illuminate\Http\Request;

class ImpactController extends Controller
{
    public function index()
    {
        return Impact::all();
    }

    public function show($id)
    {
        return Impact::find($id);
    }

    public function store(Request $request)
    {
        return ImpactHelper::handleCreate($request);
    }
}
