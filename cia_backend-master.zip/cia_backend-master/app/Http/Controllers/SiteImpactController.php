<?php

namespace App\Http\Controllers;

use App\Helpers\ImpactHelper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Site;
use App\Initiative;
use App\Impact;

class SiteImpactController extends Controller
{
    public function index($id)
    {
        $projectIds = Site::find($id)->projects->pluck('id')->toArray();
        $initiativeIds = Initiative::whereIn('project_id', $projectIds)->pluck('id')->toArray();
        return ImpactHelper::getSiteImpacts($id, $initiativeIds);
    }

    public function sumIndex($id)
    {
        $projectIds = Site::find($id)->projects->pluck('id')->toArray();
        $initiativeIds = Initiative::whereIn('project_id', $projectIds)->pluck('id')->toArray();
        return ImpactHelper::getSiteImpactsSummations($id, $initiativeIds);
    }
}