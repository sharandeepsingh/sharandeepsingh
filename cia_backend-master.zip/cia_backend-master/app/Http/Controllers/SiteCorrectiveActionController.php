<?php

namespace App\Http\Controllers;

use App\Helpers\SiteCorrectiveActionHelper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SiteCorrectiveActionController extends Controller
{
    public function index($id)
    {
        return SiteCorrectiveActionHelper::getCorrectiveActions($id);
    }
}
