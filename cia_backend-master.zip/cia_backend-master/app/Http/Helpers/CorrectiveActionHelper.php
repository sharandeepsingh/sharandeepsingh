<?php

namespace App\Helpers;

use App\CorrectiveAction;
use App\Http\Requests\CreateCorrectiveActionRequest;

class CorrectiveActionHelper
{
    public static function handleCreateRequest(
        CreateCorrectiveActionRequest $request)
    {
        $correctiveAction = self::commitCreate($request);

        if ($correctiveAction) {
            return self::successfulCreateResponse($correctiveAction);
        } else {
            return self::unsuccessfulCreateResponse();
        }
    }

    public static function commitCreate(CreateCorrectiveActionRequest $request)
    {
        return CorrectiveAction::create([
            'name' => $request->name,
            'description' => $request->description,
            'corrective_action_type_id' => $request->corrective_action_type_id,
            'owner' => $request->has('owner') ? $request->owner : null,
            'start_date' => $request->has('start_date') ? $request->start_date : null,
            'end_date' => $request->has('end_date') ? $request->end_date : null
        ]);
    }

    // RESPONSES
    public static function successfulCreateResponse($correctiveAction)
    {
        return response([
            'message' => 'Corrective action created.',
            'correctiveAction' => $correctiveAction
        ], 201);
    }

    public static function unsuccessfulCreateResponse()
    {
        return response([
            'error' => 'Corrective action could not be created.'
        ], 400);
    }
}