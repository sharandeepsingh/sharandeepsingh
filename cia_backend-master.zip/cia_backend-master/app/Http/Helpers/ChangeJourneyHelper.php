<?php

namespace App\Helpers;

use App\ChangeAspect;
use App\ChangeJourney;
use App\Initiative;
use App\Site;
use App\StakeholderGroup;
use Illuminate\Support\Facades\DB;

class ChangeJourneyHelper
{
    public static function createChangeJourneys(Site $site)
    {
        $projectIds = Site::find($site->id)->projects->pluck('id')->toArray();
        $initiativeIds = Initiative::whereIn('project_id', $projectIds)->pluck('id')->toArray();

        $internalStakeholderGroupIds = StakeholderGroup::where([
            ['internal_external', '=', 'internal'],
            ['site_id', '=', $site->id]
        ])->pluck('id');
        $externalStakeholderGroupIds = StakeholderGroup::where([
            ['internal_external', '=', 'external'],
            ['site_id', '=', $site->id]
        ])->pluck('id');

        $resultsInternal = DB::table('impacts')
            ->join('change_aspects', 'impacts.change_aspect_id', '=', 'change_aspects.id')
            ->join('stakeholder_roles', 'impacts.stakeholder_role_id', '=', 'stakeholder_roles.id')
            ->select(DB::raw('change_aspects.name as change_aspect, SUM(impacts.severity) as severity, SUM(DISTINCT stakeholder_roles.number_of_people) as number_of_people'))
            ->groupBy('change_aspects.name')
            ->where('impacts.severity', '<>', 0)
            ->whereIn('initiative_id', $initiativeIds)
            ->whereIn('stakeholder_roles.stakeholder_group_id', $internalStakeholderGroupIds)
            ->get();

        $resultsExternal = DB::table('impacts')
            ->join('change_aspects', 'impacts.change_aspect_id', '=', 'change_aspects.id')
            ->join('stakeholder_roles', 'impacts.stakeholder_role_id', '=', 'stakeholder_roles.id')
            ->select(DB::raw('change_aspects.name as change_aspect, SUM(impacts.severity) as severity, SUM(DISTINCT stakeholder_roles.number_of_people) as number_of_people'))
            ->groupBy('change_aspects.name')
            ->where('impacts.severity', '<>', 0)
            ->whereIn('initiative_id', $initiativeIds)
            ->whereIn('stakeholder_roles.stakeholder_group_id', $externalStakeholderGroupIds)
            ->get();

        foreach ($resultsInternal as $result) {
            self::directSummarizedImpact($result, $site);

            //$result->internal_external = 'internal';
        }
        foreach ($resultsExternal as $result) {
            //$result->internal_external = 'external';
        }

        //$resultsMerged = $resultsInternal->merge($resultsExternal);
    }

    public static function directSummarizedImpact($item, $site)
    {
        if ($item->change_aspect == 'Processes') {
            self::createProcessJourney($item, $site);
        } elseif ($item->change_aspect == 'Culture') {
            self::createCultureJourney($item, $site);
        } elseif ($item->change_aspect == 'Organisational Structure') {
            self::createOrganisationalStructureJourney($item, $site);
        } elseif ($item->change_aspect == 'Skills Requirement') {
            self::createSkillsRequirementJourney($item, $site);
        } elseif ($item->change_aspect == 'Tools') {
            self::createToolsJourney($item, $site);
        } elseif ($item->change_aspect == 'Workload') {
            self::createWorkloadJourney($item, $site);
        } elseif ($item->change_aspect == 'Roles and Responsibilities') {
            self::createRoleAndResponsibilitiesJourney($item, $site);
        } elseif ($item->change_aspect == 'Rewards and Recognition') {
            self::createRewardsAndRecognitionJourney($item, $site);
        } elseif ($item->change_aspect == 'Policies') {
            self::createPoliciesJourney($item, $site);
        }
    }

    public static function createOrUpdateChangeJourney(
        $item,
        $site,
        $advSev,
        $advPpl,
        $basSev,
        $basPpl
    ) {
        $change_aspect_id = ChangeAspect::where('name', '=', $item->change_aspect)->value('id');
        if ($item->severity > $advSev && $item->number_of_people > $advPpl) {
            ChangeJourney::updateOrCreate(
                ['site_id' => $site->id, 'change_aspect_id' => $change_aspect_id],
                ['level' => 'advanced']
            );
        } elseif ($item->severity > $basSev && $item->number_of_people > $basPpl) {
            ChangeJourney::updateOrCreate(
                ['site_id' => $site->id, 'change_aspect_id' => $change_aspect_id],
                ['level' => 'basic']
            );
        } else {
            ChangeJourney::where([
                ['site_id', $site->id],
                ['change_aspect_id', $change_aspect_id],
            ])->delete();
        }
    }

    public static function createProcessJourney($item, $site)
    {
        self::createOrUpdateChangeJourney($item, $site, 30, 75, 10, 15);
    }

    public static function createPoliciesJourney($item, $site)
    {
        self::createOrUpdateChangeJourney($item, $site, 15, 50, 10, 15);
    }

    public static function createCultureJourney($item, $site)
    {
        self::createOrUpdateChangeJourney($item, $site, 35, 100, 20, 30);
    }

    public static function createOrganisationalStructureJourney($item, $site)
    {
        self::createOrUpdateChangeJourney($item, $site, 20, 20, 10, 5);
    }

    public static function createSkillsRequirementJourney($item, $site)
    {
        self::createOrUpdateChangeJourney($item, $site, 25, 25, 15, 5);
    }

    public static function createToolsJourney($item, $site)
    {
        self::createOrUpdateChangeJourney($item, $site, 20, 15, 10, 5);
    }

    public static function createWorkloadJourney($item, $site)
    {
        self::createOrUpdateChangeJourney($item, $site, 30, 40, 15, 15);
    }

    public static function createRoleAndResponsibilitiesJourney($item, $site)
    {
        self::createOrUpdateChangeJourney($item, $site, 15, 10, 10, 5);
    }

    public static function createRewardsAndRecognitionJourney($item, $site)
    {
        self::createOrUpdateChangeJourney($item, $site, 40, 100, 20, 50);
    }
}