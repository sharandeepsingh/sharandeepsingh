<?php

namespace App\Helpers;

use App\Impact;
use App\StakeholderGroup;
use App\ChangeAspect;
use App\Community;

class InitiativeImpactHelper
{
    public static function handleGetInitiativeImpacts($initiative)
    {
        if (self::validateInitiative($initiative)) {
            return self::prepareInitiativeImpactResponse(
                $initiative,
                self::getInitiativeImpacts($initiative)
            );
        } else {
            return self::invalidInitiativeResponse();
        }
    }

    public static function prepareInitiativeImpactResponse($initiative, $impacts)
    {
        $return_array = [];
        $communities = Community::where('site_id', $initiative->project->site->id)->get();
        $changeAspects = ChangeAspect::all();

        foreach ($communities as $community) {
            $return_array[$community->id] = array();
            foreach ($changeAspects as $changeAspect) {
                $return_array[$community->id][$changeAspect->id] = array();
                foreach ($community->personas as $persona) {
                    $return_array[$community->id][$changeAspect->id][$persona->id] = 0;
                }
            }
        }

        foreach ($impacts as $impact) {
            $return_array[$impact->community->id][$impact->changeAspect->id][$impact->persona->id] += (int)$impact->severity;
        }

        return $return_array;
    }

    public static function validateInitiative($initiative)
    {
        if (is_null($initiative)) {
            return false;
        }
        return true;
    }

    public static function getInitiativeImpacts($initiative)
    {
        return Impact::where('initiative_id', $initiative->id)
            ->with(['persona', 'changeAspect'])
            ->get();
    }

    // RESPONSES
    public static function invalidInitiativeResponse()
    {
        return response([
            'error' => 'This initiative is not valid.'
        ], 400);
    }
}