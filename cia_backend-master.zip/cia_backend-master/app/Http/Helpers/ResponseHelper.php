<?php

namespace App\Helpers;

class ResponseHelper
{
    public static function notAuthorizedResponse()
    {
        return response([
            'error' => 'You are not authorized to perform this action.'
        ], 301);
    }
}