<?php

namespace App\Helpers;

use App\Impact;
use App\Initiative;
use App\StakeholderGroup;
use App\ChangeAspect;
use App\Community;
use App\Events\ImpactSaved;
use App\Persona;
use App\StakeholderRole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ImpactHelper
{

    /**
     * handle the storing of new impacts or overriding of existing
     * impacts
     *
     * @param Request $request
     * @return Response
     */
    public static function handleCreate(Request $request)
    {
        if ($request->impacts) {
            return self::storeImpacts($request);
        } else {
            return self::needImpactsResponse();
        }
    }

    /**
     * Commit storing of impacts to database
     *
     * @param Request $request
     * @return Response
     */
    public static function storeImpacts($request)
    {
        foreach ($request->impacts as $communityId => $values) {
            foreach ($values as $changeAspectId => $vals) {
                foreach ($vals as $personaId => $value) {
                    Impact::updateOrCreate([
                        'initiative_id' => $request->initiative_id,
                        'change_aspect_id' => $changeAspectId,
                        'persona_id' => $personaId,
                        'community_id' => $communityId,
                        'severity' => $value
                    ]);
                }
            }
        }

        //$persona = Persona::find($personaId);
        //ImpactSaved::dispatch($persona->community->site);

        return self::impactsStoredResponse();
    }

    public static function getSiteImpacts($id, $initiativeIds)
    {
        $impacts = Impact::whereIn('initiative_id', $initiativeIds)->get();
        return self::populateHeatmapImpactsArray($id, $impacts);
    }

    /**
     * get the summed impacts for a specific site
     *
     * @param int $id
     * @param array $initiativeIds
     * @return object
     */
    public static function getSiteImpactsSummations($id, $initiativeIds)
    {
        $internalStakeholderGroupIds = StakeholderGroup::where([
            ['internal_external', '=', 'internal'],
            ['site_id', '=', $id]
        ])->pluck('id');
        $externalStakeholderGroupIds = StakeholderGroup::where([
            ['internal_external', '=', 'external'],
            ['site_id', '=', $id]
        ])->pluck('id');

        $resultsInternal = DB::table('impacts')
            ->join('change_aspects', 'impacts.change_aspect_id', '=', 'change_aspects.id')
            ->join('stakeholder_roles', 'impacts.stakeholder_role_id', '=', 'stakeholder_roles.id')
            ->select(DB::raw('change_aspects.name as change_aspect, SUM(impacts.severity) as severity, SUM(DISTINCT stakeholder_roles.number_of_people) as number_of_people'))
            ->groupBy('change_aspects.name')
            ->where('impacts.severity', '<>', 0)
            ->whereIn('initiative_id', $initiativeIds)
            ->whereIn('stakeholder_roles.stakeholder_group_id', $internalStakeholderGroupIds)
            ->get();

        $resultsExternal = DB::table('impacts')
            ->join('change_aspects', 'impacts.change_aspect_id', '=', 'change_aspects.id')
            ->join('stakeholder_roles', 'impacts.stakeholder_role_id', '=', 'stakeholder_roles.id')
            ->select(DB::raw('change_aspects.name as change_aspect, SUM(impacts.severity) as severity, SUM(DISTINCT stakeholder_roles.number_of_people) as number_of_people'))
            ->groupBy('change_aspects.name')
            ->where('impacts.severity', '<>', 0)
            ->whereIn('initiative_id', $initiativeIds)
            ->whereIn('stakeholder_roles.stakeholder_group_id', $externalStakeholderGroupIds)
            ->get();

        foreach ($resultsInternal as $result) {
            $result->internal_external = 'internal';
        }
        foreach ($resultsExternal as $result) {
            $result->internal_external = 'external';
        }

        $resultsMerged = $resultsInternal->merge($resultsExternal);

        return $resultsMerged;
    }

    /**
     * Get Impacts for mutliple projects in heatmap format
     *
     * @param MultipleProjectImpactsRequest $request
     * @return array
     */
    public static function getMultipleProjectImpactsFromRequest(
        $id,
        $request
    ) {
        $impacts = self::getImpactsForHeatmapFromInitiativeIdArray(
            self::getInitiativeIdArrayFromProjectIdArray(
                $request->project_ids
            )
        );
        return self::populateHeatmapImpactsArray($id, $impacts);
    }

    /**
     * Get Impacts for multiple initiatives in heatmap format
     *
     * @param MultipleInitiativeImpactsRequest $request
     * @return array
     */
    public static function getMultipleInitiativeImpactsFromRequest(
        $id,
        $request
    ) {
        $impacts = self::getImpactsForHeatmapFromInitiativeIdArray(
            $request->initiative_ids
        );
        return self::populateHeatmapImpactsArray($id, $impacts);
    }

    /**
     * Generate the response heatmap impact array
     *
     * @param Collection $impacts
     * @return array
     */
    public static function populateHeatmapImpactsArray($id, $impacts)
    {
        $return_array = [];
        $communities = Community::where('site_id', $id)->get();
        $changeAspects = ChangeAspect::all();

        foreach ($communities as $community) {
            $return_array[$community->id] = array();
            foreach ($changeAspects as $changeAspect) {
                $return_array[$community->id][$changeAspect->id] = array();
                foreach ($community->personas as $persona) {
                    $return_array[$community->id][$changeAspect->id][$persona->id] = 0;
                }
            }
        }

        foreach ($impacts as $impact) {
            $return_array[$impact->community->id][$impact->changeAspect->id][$impact->persona->id] += (int)$impact->severity;
        }

        return $return_array;
    }

    /**
     * Get an array of initiative ids belongning to an
     * array of project ids
     *
     * @param array $projectIds
     * @return array
     */
    public static function getInitiativeIdArrayFromProjectIdArray(
        $projectIds
    ) {
        return Initiative::whereIn('project_id', $projectIds)
            ->pluck('id')
            ->toArray();
    }

    /**
     * Get Impacts from an array of initiative ids
     *
     * @param array $initiativeIds
     * @return Collection
     */
    public static function getImpactsForHeatmapFromInitiativeIdArray(
        $initiativeIds
    ) {
        return Impact::whereIn('initiative_id', $initiativeIds)
            ->selectRaw('persona_id,
                     community_id,
                     change_aspect_id,
                     SUM(severity) as severity')
            ->groupBy('persona_id', 'change_aspect_id', 'community_id')
            ->with(['persona', 'changeAspect', 'community'])
            ->get();
    }

    // RESPONSES
    public static function impactsStoredResponse()
    {
        return response([
            'message' => 'Impacts stored.'
        ], 201);
    }

    public static function needImpactsResponse()
    {
        return response([
            'error' => 'This endpoint requires a impacts array.'
        ], 400);
    }
}