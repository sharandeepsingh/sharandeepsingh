<?php

namespace App\Helpers;

use App\Initiative;
use Illuminate\Support\Facades\DB;

class SiteCorrectiveActionHelper
{
    public static function getCorrectiveActions($siteId)
    {
        return Initiative::whereIn('project_id', 
        SiteHelper::getSiteProjectIdsArray($siteId))
            ->with('correctiveActions')
            ->get();
    }
}