<?php

namespace App\Helpers;

use App\Http\Requests\CreateSiteRequest;
use App\Site;

class SiteHelper 
{
    public static function createSite(CreateSiteRequest $request)
    {
        $site = Site::create([
            'name' => $request->site_name
        ]);

        return self::validateSiteCreation($site);
    }

    public static function getSiteProjectIdsArray($siteId)
    {
        return Site::find($siteId)->projects->pluck('id')->toArray();
    }

    public static function validateSiteCreation($site)
    {
        if ($site)
        {
            return self::siteCreationSuccessfulResponse($site);
        } else {
            return self::siteCreationUnsuccessfulResponse();
        }
    }

    public static function handleSiteDelete($site)
    {
        if (!is_null($site))
        {
            self::commitSiteDelete($site);
        } else {
            return self::siteDoesNotExistResponse();
        }
    }

    public static function commitSiteDelete(Site $site)
    {
        $site->delete();
        return self::siteDeletedResponse();
    }

    // RESPONSES
    public static function siteCreationSuccessfulResponse(Site $site)
    {
        return response([
            'message' => 'Site created.',
            'site' => $site
        ], 201);
    }

    public static function siteCreationUnsuccessfulResponse()
    {
        return response([
            'error' => 'Error occurred while creating site.'
        ], 500);
    }

    public static function siteDoesNotExistResponse()
    {
        return response([
            'error' => 'Site does not exist.'
        ], 404);
    }

    public static function siteDeletedResponse()
    {
        return response([
            'message' => 'Site has been deleted.'
        ], 204);
    }
}