<?php

namespace App\Helpers;

use App\Initiative;

class InitiativeHelper
{
    public static function showInitiative(Initiative $initiative)
    {
        return self::buildInitiativeResponse($initiative);
    }

    public static function handleInitiativeCreate($id, $request)
    {
        return self::validateInitiativeCreation(
            self::createInitiative($id, $request)
        );
    }

    public static function createInitiative($id, $request)
    {
        return Initiative::create([
            'name' => $request->name,
            'project_id' => $id,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'initiative_owner' => $request->initiative_owner,
        ]);
    }

    public static function validateInitiativeCreation($initiative)
    {
        if ($initiative) {
            return self::successfulCreateInitiativeResponse($initiative);
        } else {
            return self::unsuccessfulCreateInitiativeResponse();
        }
    }

    // RESPONSES

    public static function successfulCreateInitiativeResponse($initiative)
    {
        return response([
            'message' => 'Initiative created.',
            'initiative' => $initiative
        ], 201);
    }

    public static function unsuccessfulCreateInitiativeResponse()
    {
        return response([
            'error' => 'Initiative could not be created.'
        ], 400);
    }

    public static function buildInitiativeResponse(Initiative $initiative)
    {
        return response([
            'site' => $initiative->project->site,
            'project' => $initiative->project,
            'initiative' => $initiative
        ], 200);
    }
}