<?php

namespace App\Helpers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthHelper
{
    public static function checkIfPasswordsMatch(User $user, string $password)
    {
        return Hash::check($password, $user->password);
    }

    public static function loginIsInvalid($user, string $request_password)
    {
        if (!$user || !self::checkIfPasswordsMatch($user, $request_password)) 
        {
            return true;
        }
        return false;
    }

    public static function handleLogout($user)
    {
        return self::validateLogout($user);
    }

    public static function validateLogout($user)
    {
        if (!$user) {
            return self::invalidUserLogoutResponse();
        } else {
            return self::logoutUser($user);
        }
    }

    public static function logoutUser($user)
    {
        $user->tokens()->where('id', $user->currentAccessToken()->id)->delete();
        return self::logoutResponse();
    }

    // RESPONSES

    public static function invalidCredentialsResponse()
    {
        return response([
            'message' => 'These credentials do not match our records.'
        ], 404);
    }

    public static function successfulLoginResponse(User $user, $token)
    {
        return response([
            'user' => $user,
            'token' => $token
        ], 201);
    }

    public static function logoutResponse()
    {
        return response([
            'message' => 'User logged out.'
        ], 200);
    }

    public static function invalidUserLogoutResponse()
    {
        return response([
            'error' => 'You can\'t logout if you are not logged in.'
        ], 400);
    }

}