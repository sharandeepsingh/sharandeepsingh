<?php

namespace App\Helpers;

use App\Http\Requests\RegisterRequest;
use App\Http\Requests\UpdateUserRequest;
use App\User;
use Illuminate\Support\Facades\Hash;

class UserHelper
{
    public static function getUserObjectByEmail(string $email)
    {
        return User::where('email', $email)->first();
    }

    public static function createUser(RegisterRequest $request)
    {
        $user = User::create([
            'name' => $request->username,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'is_admin' => $request->is_admin,
        ]);

        return self::checkUserCreation($user);
    }

    public static function updateUser(User $user, UpdateUserRequest $request)
    {
        $user->update($request->toArray());
        return $user;
    }

    public static function checkUserCreation($user)
    {
        if (!$user) {
            return self::unsuccessfulRegisterResponse();
        } else {
            return self::successfulRegisterResponse($user);
        }
    }

    public static function updateUserPassword(User $user, string $new_password, string $old_password)
    {
        if (self::checkOldPasswordIsCorrect($user, $old_password)) {
            return self::commitUserPasswordUpdate($user, $new_password);
        } else {
            return self::userUpdateOldPasswordIncorrectResponse();
        }
    }

    public static function commitUserPasswordUpdate(User $user, string $new_password)
    {
        $user->update([
            'password' => Hash::make($new_password)
        ]);

        return self::successfulChageUserPasswordResponse($user);
    }

    public static function checkOldPasswordIsCorrect(User $user, string $old_password)
    {
        return Hash::check($old_password, $user->password);
    }

    public static function deleteUser(User $user)
    {
        if ($user) {
            $user->delete();
            return self::userDeletedSuccessfullyResponse();
        } else {
            return self::userNotFoundResponse();
        }
    }

    // RESPONSES

    public static function userDeletedSuccessfullyResponse()
    {
        return response([
            'message' => 'User deleted successfully'
        ], 204);
    }

    public static function userNotFoundResponse()
    {
        return response([
            'error' => 'User not found.'
        ], 404);
    }

    public static function successfulRegisterResponse($user)
    {
        return response([
            'message' => 'User created successfully.',
            'user' => $user
        ], 201);
    }

    public static function unsuccessfulRegisterResponse()
    {
        return response([
            'error' => 'User registration failed'
        ], 400);
    }

    public static function successfulChageUserPasswordResponse(User $user)
    {
        return response([
            'message' => 'Password changed.',
            'user' => $user
        ], 200);
    }

    public static function unsuccessfulUserUpdateResponse()
    {
        return response([
            'error' => 'Could not update user.'
        ], 500);
    }

    public static function userUpdateOldPasswordIncorrectResponse()
    {
        return response([
            'error' => 'Old password provided is not correct.'
        ], 400);
    }
}