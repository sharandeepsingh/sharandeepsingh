<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProjectType extends Model
{
    protected $fillable = [
        'name', 'project_category_id'
    ];

    public function projectCategory()
    {
        return $this->belongsTo(\App\ProjectCategory::class);
    }

    public function projects()
    {
        return $this->hasMany(\App\Project::class);
    }
}