<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommunityMember extends Model
{
    use \App\Http\Traits\UsesUuid;

    protected $with = [
        'persona'
    ];

    protected $fillable = [
        'name', 'community_id', 'number_of_people', 'persona_id'
    ];

    public function community()
    {
        return $this->belongsTo(\App\Community::class);
    }

    public function persona()
    {
        return $this->belongsTo(\App\Persona::class);
    }
}