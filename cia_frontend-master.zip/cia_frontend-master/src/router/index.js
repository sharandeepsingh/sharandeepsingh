import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Login from '../views/auth/Login.vue'
import Heatmap from '../views/Heatmap.vue'
import ImpactInputs from '../views/ImpactInputs.vue'
import Dashboard from '../views/Dashboard.vue'
import Organogram from '../views/Organogram.vue'
import Gantt from '../views/Gantt.vue'
import Projects from '../views/Projects.vue'
import Initiatives from '../views/Initiatives.vue'
import ChangeJourneys from '../views/ChangeJourneys.vue'
import SiteManagement from '../views/SiteManagement.vue'
import UserManagement from '../views/UserManagement.vue'
import Settings from '../views/Settings.vue'

import $store from '@/store'
const localUser = localStorage.getItem('user')

Vue.use(VueRouter)

const routes = [{
    path: '/',
    name: 'dashboard',
    component: Dashboard,
  },
  {
    path: '/sites/:siteId/organogram',
    name: 'organogram',
    component: Organogram,
  },
  {
    path: '/sites/:siteId/heatmap',
    name: 'heatmap',
    component: Heatmap
  },
  {
    path: '/sites/:siteId/impact-inputs',
    name: 'impact-inputs',
    component: ImpactInputs,
    props: true
  },
  {
    path: '/sites/:siteId/gantt',
    name: 'gantt',
    component: Gantt
  },
  {
    path: '/sites/:siteId/projects',
    name: 'projects',
    component: Projects,
    props: true
  },
  {
    path: '/sites/:siteId/initiatives',
    name: 'initiatives',
    component: Initiatives
  },
  {
    path: '/sites/:siteId/change-journeys',
    name: 'change-journeys',
    component: ChangeJourneys
  },

  // SETTINGS

  {
    path: '/site-management',
    name: 'site-management',
    component: SiteManagement
  },
  {
    path: '/user-management',
    name: 'user-management',
    component: UserManagement,
    props: true
  },
  {
    path: '/settings',
    name: 'settings',
    component: Settings
  },

  // AUTH
  {
    path: '/login',
    name: 'auth.login',
    component: Login
  },
  {
    path: '/register',
    name: 'auth.register',
    component: Home
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to, from, next) => {
  const notAuthPath = to.name !== 'auth.login' && to.name !== 'auth.register'

  if (notAuthPath && !$store.getters.isAuthenticated && !localUser) {
    next('/login')
  }

  // check if its a site path
  if (to.fullPath.includes('sites/') && !$store.state.site.currentSite.data) {
    $store.dispatch('site/getSite', to.params.siteId)
      .then(() => {
        next()
      })
  } else if (to.fullPath.includes('sites/') && (to.params.siteId != $store.state.site.currentSite.data.id)) {
    $store.dispatch('site/getSite', to.params.siteId)
      .then(() => {
        next()
      })
  } else {
    next()
  }
})

router.afterEach((to) => {
  const path = to.path.substr(1).split('/')[0]
  const accountType = path === 'login' || path === 'register' || path === '404' ? '' : 'baseline'

  if (accountType) {
    const layout = `${accountType}-layout`
    $store.commit('SET_LAYOUT', layout)
  } else {
    $store.commit('SET_LAYOUT', 'auth-layout')
  }
})

export default router