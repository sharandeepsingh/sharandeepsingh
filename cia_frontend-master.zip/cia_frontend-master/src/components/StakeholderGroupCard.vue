<template>
  <div>
    <v-card min-width="400" max-width="400" outlined :elevation="4">
      <v-layout row justify-space-between align-center mx-2>
        <v-card-title>{{ stakeholderGroup.name }}</v-card-title>
        <v-chip>{{ stakeholderGroup.internal_external }}</v-chip>
      </v-layout>
      <v-layout row justify-end align-center mr-3>
        <v-dialog v-model="dialog" persistent max-width="290">
          <template v-slot:activator="{ on, attrs }">
            <v-btn v-on="on" v-bind="attrs" small text color="red">Delete Group</v-btn>
          </template>
          <v-card>
            <v-card-title class="headline">Are you sure you want to delete this group?</v-card-title>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="accent_light" text @click="dialog = false">Cancel</v-btn>
              <v-btn color="red" text @click="deleteStakeholderGroup">Delete</v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>

        <v-btn @click="addStakeholderRole" small text color="accent_light">+ Role</v-btn>
      </v-layout>
      <v-card
        v-for="stakeholderRole in stakeholderGroup.stakeholder_roles"
        :key="stakeholderRole.id"
        outlined
      >
        <NewStakeholderRoleBar
          v-if="stakeholderRole.new"
          :stakeholderGroup="stakeholderGroup"
          @save="saveStakeholderRole"
        />
        <StakeholderRoleBar
          v-else
          :stakeholderRole="stakeholderRole"
          @delete="deleteStakeholderRole"
        />
      </v-card>
    </v-card>
  </div>
</template>

<script>
import StakeholderRoleBar from "./StakeholderRoleBar";
import NewStakeholderRoleBar from "./NewStakeholderRoleBar";

export default {
  components: {
    StakeholderRoleBar,
    NewStakeholderRoleBar,
  },

  props: {
    stakeholderGroup: Object,
  },

  data() {
    return {
      newRoleActive: false,
      dialog: false,
    };
  },

  methods: {
    addStakeholderRole() {
      if (!this.newRoleActive) {
        this.stakeholderGroup.stakeholder_roles.push({
          new: true,
        });
        this.newRoleActive = true;
      }
    },

    saveStakeholderRole(role) {
      this.stakeholderGroup.stakeholder_roles.pop();
      this.stakeholderGroup.stakeholder_roles.push(role);
      this.newRoleActive = false;
    },

    deleteStakeholderRole(id) {
      console.log("start: " + id);
      for (let i = 0; i < this.stakeholderGroup.stakeholder_roles.length; i++) {
        if (id == this.stakeholderGroup.stakeholder_roles[i].id) {
          console.log("ping");
          this.stakeholderGroup.stakeholder_roles.splice(i, 1);
          i = this.stakeholderGroup.stakeholder_roles.length;
        }
      }
    },

    deleteStakeholderGroup() {
      this.$emit("delete", this.stakeholderGroup);
      this.dialog = false;
    },
  },
};
</script>

<style>
</style>