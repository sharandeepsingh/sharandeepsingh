<template>
  <v-btn @click="$emit('clicked')" class="ml-1" :color="levelColor">{{ impactLevel }}</v-btn>
</template>

<script>
export default {
  props: {
    impactLevel: String,
    selectedImpactLevel: Number,
  },
  data() {
    return {
      colors: {
        white: "#FFFFFF",
        lightBlue: "#72DDF7",
        darkBlue: "#3B6EBF",
        lightGreen: "#AEF78E",
        darkGreen: "#7CD955",
        lightYellow: "#E8D55D",
        darkYellow: "#FBB13C",
        lightRed: "#F0947D",
        darkRed: "#DB512E",
      },
    };
  },
  computed: {
    levelColor() {
      if (this.impactLevel == "H" && this.selectedImpactLevel == 3) {
        return this.colors.lightRed;
      } else if (this.impactLevel == "M" && this.selectedImpactLevel == 2) {
        return this.colors.lightYellow;
      } else if (this.impactLevel == "L" && this.selectedImpactLevel == 1) {
        return this.colors.lightGreen;
      } else {
        return "grey-lighten";
      }
    },
  },
};
</script>

<style>
</style>