<template>
  <v-btn
    @click="changeImpact"
    :color="buttonColor"
    :max-height="dimensions"
    :min-height="dimensions"
    :min-width="dimensions"
    :max-width="dimensions"
    class="ml-1"
  >{{ severity }}</v-btn>
</template>

<script>
export default {
  props: {
    dimensions: String,
    severity: Number,
    selectedImpactLevel: Number,
  },
  data() {
    return {
      colors: {
        white: "#FFFFFF",
        lightBlue: "#72DDF7",
        darkBlue: "#3B6EBF",
        lightGreen: "#AEF78E",
        darkGreen: "#7CD955",
        lightYellow: "#E8D55D",
        darkYellow: "#FBB13C",
        lightRed: "#F0947D",
        darkRed: "#DB512E",
      },
    };
  },

  computed: {
    buttonColor() {
      if (this.severity == 3) {
        return this.colors.lightRed;
      } else if (this.severity == 2) {
        return this.colors.lightYellow;
      } else if (this.severity == 1) {
        return this.colors.lightGreen;
      } else {
        return "grey-lighten";
      }
    },
  },
  methods: {
    changeImpact() {
      this.$emit("clicked");
    },
  },
};
</script>

<style>
</style>