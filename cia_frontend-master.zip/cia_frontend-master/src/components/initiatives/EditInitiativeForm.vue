<template>
  <v-card>
    <v-card-title>
      <span>Edit Initiative</span>
    </v-card-title>

    <v-card-text>
      <v-container>
        <v-row>
          <v-text-field v-model="editName" label="Initiative Name"></v-text-field>
        </v-row>
        <v-row>
          <v-col cols="6">
            <v-menu
              ref="startDateMenu"
              v-model="startDateMenu"
              :close-on-content-click="true"
              :return-value="editStartDate"
              transition="scale-transition"
              offset-y
              min-width="290px"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="editStartDate"
                  label="Choose a start date"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker v-model="editStartDate" no-title scrollable></v-date-picker>
            </v-menu>
          </v-col>
          <v-col cols="6">
            <v-menu
              ref="endDateMenu"
              v-model="endDateMenu"
              :close-on-content-click="true"
              :return-value="editEndDate"
              transition="scale-transition"
              offset-y
              min-width="290px"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="editEndDate"
                  label="Choose a start date"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker v-model="editEndDate" no-title scrollable></v-date-picker>
            </v-menu>
          </v-col>
        </v-row>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="close">Cancel</v-btn>
          <v-btn color="blue darken-1" text @click="save">Save</v-btn>
        </v-card-actions>
      </v-container>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  props: {
    initiative: {
      type: Object,
    },
  },

  data() {
    return {
      editName: "",
      editStartDate: new Date().toISOString().substr(0, 10),
      editEndDate: new Date().toISOString().substr(0, 10),
      startDateMenu: false,
      endDateMenu: false,
    };
  },

  created() {
    this.editName = this.initiative.name;
    this.editStartDate = this.initiative.start_date;
    this.editEndDate = this.initiative.end_date;
    console.log(this.initiative);
  },

  computed: {
    emitInitiative() {
      let obj = {
        id: this.initiative.id,
        name: this.editName,
        projectId: this.initiative.project_id,
        startDate: this.editStartDate,
        endDate: this.editEndDate,
      };

      return obj;
    },
  },

  methods: {
    close() {
      this.$emit("close");
    },

    save() {
      if (this.initiative.name == "") {
        // alert the user
      } else {
        this.initiative.name = this.editName;
        this.initiative.start_date = this.editStartDate;
        this.initiative.end_date = this.editEndDate;
        this.$emit("save", this.emitInitiative);
      }
    },
  },
};
</script>

<style>
</style>