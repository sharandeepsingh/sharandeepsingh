<template>
  <v-card>
    <v-card-title>
      <span>Create a new Initiative</span>
    </v-card-title>

    <v-card-text>
      <v-container>
        <v-row>
          <v-text-field v-model="newInitiativeName" label="Initiative Name"></v-text-field>
        </v-row>
        <v-row>
          <v-col cols="6">
            <v-menu
              ref="startDateMenu"
              v-model="startDateMenu"
              :close-on-content-click="true"
              transition="scale-transition"
              offset-y
              min-width="290px"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="startDate"
                  label="Choose a start date"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker v-model="startDate" no-title scrollable></v-date-picker>
            </v-menu>
          </v-col>
          <v-col cols="6">
            <v-menu
              ref="endDateMenu"
              v-model="endDateMenu"
              :close-on-content-click="true"
              :return-value="endDate"
              transition="scale-transition"
              offset-y
              min-width="290px"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="endDate"
                  label="Choose a start date"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker v-model="endDate" no-title scrollable></v-date-picker>
            </v-menu>
          </v-col>
        </v-row>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="close">Cancel</v-btn>
          <v-btn color="blue darken-1" text @click="save">Save</v-btn>
        </v-card-actions>
      </v-container>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  props: {
    project: {
      type: Object,
    },
  },

  data() {
    return {
      newInitiativeName: "",
      startDate: new Date().toISOString().substr(0, 10),
      startDateMenu: false,
      endDate: new Date().toISOString().substr(0, 10),
      endDateMenu: false,
    };
  },

  created() {},

  computed: {
    initiative() {
      let obj = {
        projectId: this.project.id,
        initiativeName: this.newInitiativeName,
        startDate: this.startDate,
        endDate: this.endDate,
      };
      return obj;
    },
  },

  methods: {
    close() {
      this.$emit("close");
    },

    save() {
      if (this.newInitiativeName == "") {
        // alert the user
      } else {
        this.$emit("save", this.initiative);
      }
    },
  },
};
</script>

<style>
</style>