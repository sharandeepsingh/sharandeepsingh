<template>
  <v-card>
    <v-card-title>
      <span>Create a new Project</span>
    </v-card-title>

    <v-card-text>
      <v-container>
        <v-row>
          <v-text-field v-model="newProjectName" label="Project Name"></v-text-field>
        </v-row>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="close">Cancel</v-btn>
          <v-btn color="blue darken-1" text @click="save">Save</v-btn>
        </v-card-actions>
      </v-container>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  data() {
    return {
      newProjectName: "",
    };
  },

  methods: {
    close() {
      this.$emit("close");
    },

    save() {
      if (this.newProjectName == "") {
        // alert the user
      } else {
        this.$emit("save", this.newProjectName);
      }
    },
  },
};
</script>

<style>
</style>