<template>
    <v-container fluid fill-height full-width>
        <v-row
            justify="center">
            <v-progress-circular
                :size="70"
                :width="7"
                color="accent_light"
                indeterminate></v-progress-circular>
        </v-row>
    </v-container>
</template>

<script>
export default {
    data () {
        return {
            
        }
    },

    
}
</script>