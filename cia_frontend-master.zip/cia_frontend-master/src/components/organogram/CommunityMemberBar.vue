<template>
  <v-list-item>
    <v-card-text>{{ persona.name }}</v-card-text>
    <v-icon>mdi-account</v-icon>
    <v-card-text>{{ persona.number_of_people }}</v-card-text>
    <v-dialog v-model="dialog" persistent max-width="290">
      <template v-slot:activator="{ on, attrs }">
        <v-btn v-on="on" v-bind="attrs" text small color="red">Delete</v-btn>
      </template>
      <v-card>
        <v-card-title class="headline">Are you sure you want to delete these community member(s)?</v-card-title>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="accent_light" text @click="dialog = false">Cancel</v-btn>
          <v-btn text small color="red" @click="deleteMember">Delete</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-list-item>
</template>

<script>
import axios from "../../services/ApiClient.js";

export default {
  props: {
    persona: Object,
    community: Object,
  },

  data() {
    return {
      dialog: false,
    };
  },

  methods: {
    deletePersona() {
      axios
        .delete(
          "/communities/" +
            this.community.id +
            "/remove-persona/" +
            this.persona.id
        )
        .catch((error) => {
          throw error;
        });

      console.log("before start: " + this.persona.id);
      this.$emit("delete", this.persona.id);
      this.dialog = false;
    },
  },
};
</script>

<style>
</style>