<template>
  <div>
    <v-card min-width="400" max-width="400" outlined :elevation="4">
      <v-layout row justify-space-between align-center mx-2>
        <v-card-title>{{ community.name }}</v-card-title>
        <v-chip>{{ community.internal_external }}</v-chip>
      </v-layout>
      <v-layout row justify-end align-center mr-3>
        <v-dialog v-model="dialog" persistent max-width="290">
          <template v-slot:activator="{ on, attrs }">
            <v-btn v-on="on" v-bind="attrs" small text color="red">Delete Community</v-btn>
          </template>
          <v-card>
            <v-card-title class="headline">Are you sure you want to delete this community?</v-card-title>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="accent_light" text @click="dialog = false">Cancel</v-btn>
              <v-btn color="red" text @click="deleteCommunity">Delete</v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>

        <v-btn @click="addPersona" small text color="accent_light">+ Persona</v-btn>
      </v-layout>
      <v-card v-for="persona in community.personas" :key="persona.id" outlined>
        <NewCommunityPersonaBar v-if="persona.new" :community="community" @save="savePersona" />
        <CommunityPersonaBar
          v-else
          :community="community"
          :persona="persona"
          @delete="deletePersona"
        />
      </v-card>
    </v-card>
  </div>
</template>

<script>
import CommunityPersonaBar from "./CommunityPersonaBar";
import NewCommunityPersonaBar from "./NewCommunityPersonaBar";

export default {
  components: {
    CommunityPersonaBar,
    NewCommunityPersonaBar,
  },

  props: {
    community: Object,
  },

  data() {
    return {
      newPersonaActive: false,
      dialog: false,
    };
  },

  methods: {
    addPersona() {
      if (!this.newPersonaActive) {
        this.community.personas.push({
          new: true,
        });
        this.newPersonaActive = true;
      }
    },

    savePersona(persona) {
      this.community.personas.pop();
      this.community.personas.push(persona);
      this.newPersonaActive = false;
    },

    deletePersona(id) {
      console.log("start: " + id);
      for (let i = 0; i < this.community.personas.length; i++) {
        if (id == this.community.personas[i].id) {
          this.community.personas.splice(i, 1);
          i = this.community.personas.length;
        }
      }
    },

    deleteCommunity() {
      this.$emit("delete", this.community);
      this.dialog = false;
    },
  },
};
</script>

<style>
</style>