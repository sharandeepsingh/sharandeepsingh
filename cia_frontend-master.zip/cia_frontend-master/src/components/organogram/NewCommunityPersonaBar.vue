<template>
  <v-list-item>
    <v-card-text>
      <v-select
        :items="personas"
        v-model="persona.id"
        name="persona"
        item-text="name"
        item-value="id"
        label="Persona"
      ></v-select>
    </v-card-text>
    <v-card-text>
      <v-text-field label="# of people" align-center v-model="persona.member_count"></v-text-field>
    </v-card-text>
    <v-btn @click="savePersona" text small color="accent_light">save</v-btn>
  </v-list-item>
</template>

<script>
import axios from "../../services/ApiClient.js";
export default {
  props: {
    community: Object,
  },

  data() {
    return {
      persona: {
        id: 0,
        name: "",
        member_count: 0,
      },
      personas: [],
    };
  },

  created() {
    this.personas = this.$store.getters.personas;
  },

  methods: {
    savePersona() {
      axios
        .post(
          "/communities/" +
            this.community.id +
            "/add-persona/" +
            this.persona.id,
          {
            member_count: this.persona.member_count,
          }
        )
        .then((response) => {
          this.persona.name = response.data.persona.name;
          this.$emit("save", this.persona);
        })
        .catch((error) => {
          throw error;
        });
    },
  },
};
</script>

<style>
</style>