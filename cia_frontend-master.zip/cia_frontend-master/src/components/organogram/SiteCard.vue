<template>
  <v-card
    class="mx-auto"
    max-width="400"
    min-width="400"
    outlined
    :elevation="4"
    rounded
    color="primary"
    dark
  >
    <v-list-item>
      <v-list-item-title class="headline mb-1">
        {{
        siteName
        }}
      </v-list-item-title>
    </v-list-item>
    <v-list-item>
      <v-list-item-title class="mb-1">Total Employees: {{ employeeCount }}</v-list-item-title>
    </v-list-item>
    <v-card-actions>
      <v-btn @click="emitAddCommunity" text color="accent_light">+ Add a Community</v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  props: {
    siteName: String,
    employeeCount: Number,
  },
  methods: {
    emitAddCommunity() {
      this.$emit("addCommunity");
    },
  },
};
</script>

<style></style>
