<template>
  <v-list-item>
    <v-card-text>
      <v-text-field label="Name" align-center mr-2 v-model="member.name"></v-text-field>
    </v-card-text>
    <v-card-text>
      <v-select
        :items="personas"
        v-model="member.persona"
        name="persona"
        item-text="name"
        item-value="id"
        label="Persona"
      ></v-select>
    </v-card-text>
    <v-card-text>
      <v-text-field label="# of people" align-center v-model="member.number_of_people"></v-text-field>
    </v-card-text>
    <v-btn @click="saveMember" text small color="accent_light">save</v-btn>
  </v-list-item>
</template>

<script>
import axios from "../../services/ApiClient.js";
export default {
  props: {
    community: Object,
  },

  data() {
    return {
      member: {
        name: "",
        persona: {},
        number_of_people: 0,
      },
      personas: [],
    };
  },

  created() {
    this.personas = this.$store.getters.personas;
  },

  methods: {
    saveMember() {
      axios
        .post("/communities/" + this.community.id + "/members", {
          name: this.member.name,
          persona_id: this.member.persona,
          number_of_people: this.member.number_of_people,
        })
        .then(() => {
          this.$emit("save", this.member);
        })
        .catch((error) => {
          throw error;
        });
    },
  },
};
</script>

<style>
</style>