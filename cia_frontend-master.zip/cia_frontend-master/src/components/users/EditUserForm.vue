<template>
  <v-card>
    <v-card-title>
      <span>Create a new Usert</span>
    </v-card-title>

    <v-card-text>
      <v-container>
        <v-row>
          <v-text-field
            v-model="editName"
            :rules="[rules.required, rules.minName, rules.maxName]"
            label="User Name"
          ></v-text-field>
        </v-row>
        <v-row>
          <v-text-field v-model="editEmail" label="User Email"></v-text-field>
        </v-row>
        <v-row>
          <v-checkbox v-model="editIsAdmin" color="accent_light" label="Administrator"></v-checkbox>
        </v-row>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="close">Cancel</v-btn>
          <v-btn color="blue darken-1" text @click="update">Update</v-btn>
        </v-card-actions>
      </v-container>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  props: {
    user: {
      type: Object,
    },
  },

  created() {
    this.editName = this.user.name;
    this.editEmail = this.user.email;
    this.editIsAdmin = this.user.is_admin;
  },

  data() {
    return {
      show1: false,
      editName: "",
      editEmail: "",
      editIsAdmin: "",
      rules: {
        required: (value) => !!value || "Required",
        min: (v) => v.length >= 8 || "Min 8 characters",
        minName: (mi) => mi.length >= 3 || "Min 3 characters",
        maxName: (ma) => ma.length <= 30 || "Max 30 characters",
      },
    };
  },

  computed: {},

  methods: {
    close() {
      this.editName = this.user.name;
      this.editEmail = this.user.email;
      this.editIsAdmin = this.user.is_admin;
      this.$emit("close");
    },

    update() {
      this.user.name = this.editName;
      this.user.email = this.editEmail;
      this.user.is_admin = this.editIsAdmin;
      this.$emit("update", this.user);
    },
  },
};
</script>

<style>
</style>