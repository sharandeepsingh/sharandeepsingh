<template>
  <v-card>
    <v-card-title>
      <span>Create a new Usert</span>
    </v-card-title>

    <v-card-text>
      <v-container>
        <v-row>
          <v-text-field
            v-model="newUserName"
            :rules="[rules.required, rules.minName, rules.maxName]"
            label="User Name"
          ></v-text-field>
        </v-row>
        <v-row>
          <v-text-field v-model="newUserEmail" label="User Email"></v-text-field>
        </v-row>
        <v-row>
          <v-text-field
            v-model="newPassword"
            :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
            :rules="[rules.required, rules.min]"
            :type="show1 ? 'text' : 'password'"
            name="password-input"
            label="Enter password"
            hint="At least 8 characters"
            counter
            @click:append="show1 = !show1"
          ></v-text-field>
        </v-row>
        <v-row>
          <v-checkbox v-model="isAdmin" color="accent_light" label="Administrator" value="true"></v-checkbox>
        </v-row>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="close">Cancel</v-btn>
          <v-btn color="blue darken-1" text @click="save">Save</v-btn>
        </v-card-actions>
      </v-container>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  data() {
    return {
      isAdmin: null,
      newUserName: "",
      newUserEmail: "",
      newPassword: "",
      show1: false,
      rules: {
        required: (value) => !!value || "Required",
        min: (v) => v.length >= 8 || "Min 8 characters",
        minName: (mi) => mi.length >= 3 || "Min 3 characters",
        maxName: (ma) => ma.length <= 30 || "Max 30 characters",
      },
    };
  },

  computed: {
    user() {
      let obj = {
        username: this.newUserName,
        email: this.newUserEmail,
        is_admin: this.isAdmin ? 1 : 0,
        password: this.newPassword,
      };

      return obj;
    },
  },

  methods: {
    close() {
      this.$emit("close");
    },

    save() {
      this.$emit("save", this.user);
    },
  },
};
</script>

<style>
</style>