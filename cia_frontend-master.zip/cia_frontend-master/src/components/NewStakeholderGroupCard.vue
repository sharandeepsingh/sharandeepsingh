<template>
  <v-card min-width="400" max-width="400" outlined :elevation="4">
    <v-card-title>
      <v-text-field label="Enter Stakeholder Group Name" align-center mr-2 v-model="group.name"></v-text-field>
    </v-card-title>

    <v-card-text>
      <v-switch v-model="group.IE" :label="group.IE ? 'External' : 'Internal'"></v-switch>
    </v-card-text>

    <v-card-actions>
      <v-btn text @click="$emit('save', group)" color="accent_light white--text">Save</v-btn>
      <v-btn text @click="$emit('cancel')" color="red white--text">Cancel</v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  data() {
    return {
      group: {
        name: "",
        IE: false,
      },
    };
  },
};
</script>

<style>
</style>