<template>
  <v-list-item>
    <v-card-text>{{ stakeholderRole.name }}</v-card-text>
    <v-icon>mdi-account</v-icon>
    <v-card-text>{{ stakeholderRole.number_of_people }}</v-card-text>
    <v-dialog v-model="dialog" persistent max-width="290">
      <template v-slot:activator="{ on, attrs }">
        <v-btn v-on="on" v-bind="attrs" text small color="red">Delete</v-btn>
      </template>
      <v-card>
        <v-card-title class="headline">Are you sure you want to delete this role?</v-card-title>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="accent_light" text @click="dialog = false">Cancel</v-btn>
          <v-btn text small color="red" @click="deleteRole">Delete</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-list-item>
</template>

<script>
import axios from "../services/ApiClient.js";

export default {
  props: {
    stakeholderRole: Object,
  },

  data() {
    return {
      dialog: false,
    };
  },

  methods: {
    deleteRole() {
      axios
        .delete("/stakeholder-roles/" + this.stakeholderRole.id)
        .catch((error) => {
          throw error;
        });

      console.log("before start: " + this.stakeholderRole.id);
      this.$emit("delete", this.stakeholderRole.id);
      this.dialog = false;
    },
  },
};
</script>

<style>
</style>