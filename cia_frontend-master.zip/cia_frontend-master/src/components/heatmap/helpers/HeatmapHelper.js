export default {
    generateEmptyImpactArray(stakeholderGroups, changeAspects) {
        let impacts = {}

        for (var group in stakeholderGroups) {
            impacts[stakeholderGroups[group].id] = {};
            for (var aspect in changeAspects) {
                impacts[stakeholderGroups[group].id][
                    changeAspects[aspect].id
                ] = {};
                for (var role in stakeholderGroups[group].stakeholder_roles) {
                    impacts[stakeholderGroups[group].id][
                        changeAspects[aspect].id
                    ][stakeholderGroups[group].stakeholder_roles[role].id] = 0;
                }
            }
        }

        return impacts
    },

    expandStakeholderGroup(stakeholderGroups, stakeholderGroup) {
        if (!stakeholderGroup.number_of_people) {
            let firstIndex = -1;

            for (let i = 0; i < stakeholderGroups.length; i++) {
                stakeholderGroups[i].color = "primary";
                if (stakeholderGroups[i].number_of_people) {
                    firstIndex = i - 1;
                    stakeholderGroups.splice(i, 1);
                    i--;
                }
            }

            let index = 0;
            for (let i = 0; i < stakeholderGroups.length; i++) {
                if (stakeholderGroups[i].id == stakeholderGroup.id) {
                    index = i;
                    break;
                }
            }

            if (!(firstIndex == index)) {
                stakeholderGroups[index].color = "accent_light";
                stakeholderGroups[index].stakeholder_roles.forEach((role) => {
                    stakeholderGroups.splice(index + 1, 0, role);
                });
            }
            return stakeholderGroups
        }
    }
}