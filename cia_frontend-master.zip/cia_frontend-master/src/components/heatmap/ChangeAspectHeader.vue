<template>
  <v-card
    class="mb-1"
    min-height="45"
    max-height="45"
    min-width="215"
    max-width="215"
    :key="aspect.key"
    color="primary"
  >
    <div
      :style="{ color: 'white', 'line-height': '45px', 'text-align': 'center', height: '45px' }"
      class="mx-2 fill-height"
    >{{ aspect.name }}</div>
  </v-card>
</template>

<script>
export default {
  props: {
    aspect: Object,
  },
};
</script>

<style>
</style>