<template>
  <v-card
    :color="sColor"
    :style="{ 'text-orientation': 'mixed',
              'writing-mode': 'vertical-rl' }"
    class="mb-2"
    min-height="180"
    max-height="180"
    min-width="45"
    max-width="45"
  >
    <v-card-text :style="{ color: 'white' }">{{ stakeholderGroup.name }}</v-card-text>
  </v-card>
</template>

<script>
export default {
  props: {
    stakeholderGroup: Object,
    sColor: String,
  },
  computed: {},
  watch: {},
};
</script>

<style>
</style>