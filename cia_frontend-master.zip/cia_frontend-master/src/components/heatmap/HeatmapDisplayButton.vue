<template>
  <v-btn
    v-if="groupButton"
    @click="displayTooltip"
    :color="buttonColor"
    :max-height="dimensions"
    :min-height="dimensions"
    :min-width="dimensions"
    :max-width="dimensions"
    dark
    class="ml-1"
  >{{ severity }}</v-btn>
  <v-btn
    v-else
    @click="displayTooltip"
    :color="roleButtonColor"
    :max-height="dimensions"
    :min-height="dimensions"
    :min-width="dimensions"
    :max-width="dimensions"
    class="ml-1"
  >{{ severity }}</v-btn>
</template>

<script>
export default {
  props: {
    dimensions: String,
    severity: Number,
    type: String,
  },

  data() {
    return {
      colors: {
        white: "#FFFFFF",
        lightBlue: "#72DDF7",
        darkBlue: "#3B6EBF",
        lightGreen: "#AEF78E",
        darkGreen: "#7CD955",
        lightYellow: "#E8D55D",
        darkYellow: "#FBB13C",
        lightRed: "#F0947D",
        darkRed: "#DB512E",
      },
    };
  },

  computed: {
    buttonColor() {
      if (this.severity > 25) {
        return this.colors.darkRed;
      } else if (this.severity > 22) {
        return this.colors.lightRed;
      } else if (this.severity > 19) {
        return this.colors.darkYellow;
      } else if (this.severity > 16) {
        return this.colors.lightYellow;
      } else if (this.severity > 13) {
        return this.colors.darkGreen;
      } else if (this.severity > 10) {
        return this.colors.lightGreen;
      } else if (this.severity > 7) {
        return this.colors.darkBlue;
      } else if (this.severity > 1) {
        return this.colors.lightBlue;
      } else {
        return "secondary";
      }
    },

    roleButtonColor() {
      if (this.severity > 21) {
        return this.colors.darkRed;
      } else if (this.severity > 18) {
        return this.colors.lightRed;
      } else if (this.severity > 15) {
        return this.colors.darkYellow;
      } else if (this.severity > 12) {
        return this.colors.lightYellow;
      } else if (this.severity > 9) {
        return this.colors.darkGreen;
      } else if (this.severity > 6) {
        return this.colors.lightGreen;
      } else if (this.severity > 3) {
        return this.colors.darkBlue;
      } else if (this.severity > 1) {
        return this.colors.lightBlue;
      } else {
        return "this.colors.white";
      }
    },

    groupButton() {
      if (this.type == "group") {
        return true;
      } else {
        return false;
      }
    },
  },

  methods: {
    displayTooltip() {
      this.$emit("heatmapButtonClick");
    },
  },
};
</script>

<style>
</style>