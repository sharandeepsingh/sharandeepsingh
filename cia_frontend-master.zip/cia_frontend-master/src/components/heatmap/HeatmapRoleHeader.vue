<template>
  <v-card
    :style="{ 'text-orientation': 'mixed',
              'writing-mode': 'vertical-rl' }"
    class="mb-2"
    min-height="180"
    max-height="180"
    min-width="45"
    max-width="45"
    color="grey lighten-2"
    flat
  >
    <v-card-text>{{ stakeholderGroup.name }}</v-card-text>
  </v-card>
</template>

<script>
export default {
  props: {
    stakeholderGroup: Object,
  },
};
</script>

<style>
</style>