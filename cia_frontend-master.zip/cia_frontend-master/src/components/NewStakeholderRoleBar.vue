<template>
  <v-list-item>
    <v-card-text>
      <v-text-field label="Name" align-center mr-2 v-model="role.name"></v-text-field>
    </v-card-text>
    <v-icon>mdi-account</v-icon>
    <v-card-text>
      <v-text-field align-center v-model="role.number_of_people"></v-text-field>
    </v-card-text>
    <v-btn @click="saveRole" text small color="accent_light">save</v-btn>
  </v-list-item>
</template>

<script>
import axios from "../services/ApiClient.js";
export default {
  props: {
    stakeholderGroup: Object,
  },

  data() {
    return {
      role: {
        name: "",
        number_of_people: 0,
      },
    };
  },

  methods: {
    saveRole() {
      axios
        .post(
          "/stakeholder-groups/" +
            this.stakeholderGroup.id +
            "/stakeholder-roles",
          {
            name: this.role.name,
            number_of_people: this.role.number_of_people,
          }
        )
        .then(() => {
          this.$emit("save", this.role);
        })
        .catch((error) => {
          throw error;
        });
    },
  },
};
</script>

<style>
</style>