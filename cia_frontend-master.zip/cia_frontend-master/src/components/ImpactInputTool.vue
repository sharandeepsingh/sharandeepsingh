<template>
  <div>
    <v-container fluid>
      <table>
        <thead>
          <tr>
            <th></th>
            <th v-for="stakeholderGroup in stakeholderGroups" :key="stakeholderGroup.id">
              <heatmap-role-header
                v-if="stakeholderGroup.number_of_people"
                :stakeholderGroup="stakeholderGroup"
              ></heatmap-role-header>
              <heatmap-header
                v-else
                :stakeholderGroup="stakeholderGroup"
                :sColor="stakeholderGroup.color"
              ></heatmap-header>
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="aspect in changeAspects" :key="aspect.id">
            <td>
              <change-aspect-header :aspect="aspect"></change-aspect-header>
            </td>
            <td v-for="stakeholderGroup in stakeholderGroups" :key="stakeholderGroup.id">
              <impact-input-button
                v-if="stakeholderGroup.number_of_people"
                :selectedImpactLevel="selectedImpactLevel"
                :severity="roleImpacts[stakeholderGroup.id][aspect.id]"
                @clicked="impactInputClicked(stakeholderGroup, aspect)"
                dimensions="45"
              ></impact-input-button>
              <heatmap-display-button
                v-else
                :severity="groupImpacts[stakeholderGroup.id][aspect.id]"
                dimensions="45"
                type="group"
                @heatmapButtonClick="expandStakeholderGroup(stakeholderGroup)"
              ></heatmap-display-button>
            </td>
          </tr>
        </tbody>
      </table>
    </v-container>
  </div>
</template>

<script>
import HeatmapDisplayButton from "./heatmap/HeatmapDisplayButton.vue";
import HeatmapHeader from "./heatmap/HeatmapHeader.vue";
import HeatmapRoleHeader from "./heatmap/HeatmapRoleHeader.vue";
import ChangeAspectHeader from "./heatmap/ChangeAspectHeader.vue";
import ImpactInputButton from "./impactinput/ImpactInputButton.vue";

export default {
  components: {
    HeatmapDisplayButton,
    HeatmapHeader,
    HeatmapRoleHeader,
    ChangeAspectHeader,
    ImpactInputButton,
  },
  props: {
    stakeholderGroups: Array,
    changeAspects: Array,
    impacts: Object,
    expandedStakeholderGroup: Object,
    selectedImpactLevel: Number,
  },
  computed: {
    stakeholderGroupsLength() {
      return this.stakeholderGroups.length;
    },
    groupImpacts() {
      let obj = {};

      for (let group in this.impacts) {
        obj[group] = {};
        for (let asp in this.impacts[group]) {
          obj[group][asp] = {};
          var num = 0;
          for (let role in this.impacts[group][asp]) {
            num += parseInt(this.impacts[group][asp][role]);
          }
          obj[group][asp] = num;
        }
      }

      return obj;
    },

    roleImpacts() {
      let obj = {};

      for (let role in this.expandedStakeholderGroup.stakeholder_roles) {
        obj[this.expandedStakeholderGroup.stakeholder_roles[role].id] = {};
        for (let asp in this.impacts[this.expandedStakeholderGroup.id]) {
          obj[this.expandedStakeholderGroup.stakeholder_roles[role].id][
            asp
          ] = parseInt(
            this.impacts[this.expandedStakeholderGroup.id][asp][
              this.expandedStakeholderGroup.stakeholder_roles[role].id
            ]
          );
        }
      }

      return obj;
    },
  },

  created() {},

  methods: {
    expandStakeholderGroup(stakeholderGroup) {
      this.$emit("expandStakeholderGroup", stakeholderGroup);
    },

    impactInputClicked(stakeholderGroup, changeAspect) {
      this.$emit("impactInputClicked", stakeholderGroup, changeAspect);
    },
  },

  watch: {},
};
</script>

<style>
</style>