import Vue from 'vue'
import App from './App.vue'
import axios from 'axios'
import router from './router'
import store from './store'
import vuetify from './plugins/vuetify'
import VueApexCharts from 'vue-apexcharts'
import Loader from './components/Loader.vue'
import GSTC from "vue-gantt-schedule-timeline-calendar";

// Resgister global components
Vue.component('apexchart', VueApexCharts)
Vue.component('loader', Loader)
Vue.component('gstc', GSTC)

require('@/assets/css/style.css')

Vue.config.productionTip = false

new Vue({
  router,
  store,
  vuetify,
  created() {
    const userString = localStorage.getItem('user')
    if (userString) {
      const userData = JSON.parse(userString)
      this.$store.commit('SET_USER_DATA', userData)
    }
    axios.interceptors.response.use(
      response => response,
      error => {
        if (error.response.status === 401) {
          this.$router.push('/login')
          this.$store.commit('CLEAR_USER_DATA')
        }
        return Promise.reject(error)
      }
    )
  },
  render: h => h(App)
}).$mount('#app')