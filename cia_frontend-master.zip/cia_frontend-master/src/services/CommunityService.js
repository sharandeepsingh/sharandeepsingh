import axios from './ApiClient'

export default {
    getSiteCommunities(siteId) {
        return axios.get('/sites/' + siteId + '/communities')
    },

    getSiteCommunitiesWithMembers(siteId) {
        return axios.get('/sites/' + siteId + '/communities-with-members')
    },

    saveCommunity(community) {
        return axios.post('/sites/' + community.siteId + '/communities', {
            site_id: community.siteId,
            name: community.name,
            internal_external: community.IE
        })
    },

    deleteCommunity(community) {
        return axios.delete('/communities/' + community.id)
    }
}