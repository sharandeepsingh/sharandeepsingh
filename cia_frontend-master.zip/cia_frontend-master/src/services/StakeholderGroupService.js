import axios from './ApiClient'

export default {
    getSiteStakeholderGroups(siteId) {
        return axios.get('/sites/' + siteId + '/stakeholder-groups')
    },

    getSiteStakeholderGroupsWithRoles(siteId) {
        return axios.get('/sites/' + siteId + '/stakeholder-groups-with-roles')
    },

    saveStakeholderGroup(stakeholderGroup) {
        return axios.post('/sites/' + stakeholderGroup.siteId + '/stakeholder-groups', {
            site_id: stakeholderGroup.siteId,
            name: stakeholderGroup.name,
            internal_external: stakeholderGroup.IE
        })
    },

    deleteStakeholderGroup(stakeholderGroup) {
        return axios.delete('/stakeholder-groups/' + stakeholderGroup.id)
    }
}