import axios from './ApiClient'

export default {
    getSites() {
        return axios.get('/sites')
    },

    getSite(siteId) {
        return axios.get('/sites/' + siteId)
    }
}