import axios from './ApiClient'

export default {
    getChangeAspects() {
        return axios.get('/change-aspects')
    }
}