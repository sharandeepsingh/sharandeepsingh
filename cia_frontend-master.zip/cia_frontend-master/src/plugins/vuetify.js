import Vue from 'vue';
import Vuetify from 'vuetify/lib';

Vue.use(Vuetify);

export default new Vuetify({
    theme: {
      themes: {
        light: {
          primary: '#625F63',
          secondary: '#72727E',
          accent: '#447604',
          accent_light: '#6CC551',
          error: '#fc7a1e',
          text: {
            primary: '#625F63'
          }
        }
      }
    }
  })
  