<template>
  <v-app>
    <v-main>
      <v-container
        class="fill-height bg-gradient"
        fluid
      >

        <v-row
          align="center"
          justify="center"
        >
          <router-view></router-view>
        </v-row>
        <v-footer class="bg-gradient white--text" app>
          <span>&copy;</span>
          <span class="logo logo-font-bold ml-1">Del<span class="logo logo-font-light">oitte</span></span>
        </v-footer>
      </v-container>
    </v-main>
  </v-app>
</template>

<script>

export default {
  components: {
  }
}
</script>
