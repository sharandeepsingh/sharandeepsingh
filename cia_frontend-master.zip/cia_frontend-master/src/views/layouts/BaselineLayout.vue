<template>
  <v-app id="inspire">
    <loader v-if="!layoutLoaded"></loader>
    <v-container v-else class="fill-height full-width overflow-auto" fluid>
      <v-navigation-drawer v-model="drawer" app>
        <v-list-item link :to="homeRoute">
          <v-list-item-icon>
            <v-icon>{{ `mdi-home` }}</v-icon>
          </v-list-item-icon>
          <v-list-item-content>Home</v-list-item-content>
        </v-list-item>

        <v-list-item>
          <v-list-item-content>
            <v-list-item-title class="title">Sites</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-divider></v-divider>

        <v-list nav>
          <v-list-group
            v-for="(site, i) in sites"
            prepend-icon="mdi-dump-truck"
            :value="false"
            :key="i"
            v-model="site.active"
            mandatory
            color="accent_light"
          >
            <template v-slot:activator>
              <v-list-item-title v-text="site.name"></v-list-item-title>
            </template>

            <v-list-item @click="navigateToOrganogram(site.id)" link>
              <v-list-item-content>Organogram</v-list-item-content>
            </v-list-item>
            <v-list-item @click="navigateToHeatmap(site.id)" link>
              <v-list-item-content>Heatmap</v-list-item-content>
            </v-list-item>
            <v-list-item @click="navigateToGantt(site.id)" link>
              <v-list-item-content>Gantt</v-list-item-content>
            </v-list-item>
            <v-list-item @click="navigateToProjects(site.id)" link>
              <v-list-item-content>Projects</v-list-item-content>
            </v-list-item>
            <v-list-item @click="navigateToChangeJourneys(site.id)" link>
              <v-list-item-content>Change Journeys</v-list-item-content>
            </v-list-item>
          </v-list-group>
        </v-list>

        <v-list-item>
          <v-list-item-content>
            <v-list-item-title class="title">Administration</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-divider></v-divider>

        <v-list nav>
          <v-list-item link :to="siteManagementRoute">
            <v-list-item-icon>
              <v-icon>{{ `mdi-cog-outline ` }}</v-icon>
            </v-list-item-icon>
            <v-list-item-content>Site Management</v-list-item-content>
          </v-list-item>
          <v-list-item link :to="userManagementRoute">
            <v-list-item-icon>
              <v-icon>{{ `mdi-account-cog ` }}</v-icon>
            </v-list-item-icon>
            <v-list-item-content>User management</v-list-item-content>
          </v-list-item>
          <v-list-item link :to="settingsRoute">
            <v-list-item-icon>
              <v-icon>{{ `mdi-cog-outline ` }}</v-icon>
            </v-list-item-icon>
            <v-list-item-content>Settings</v-list-item-content>
          </v-list-item>
        </v-list>

        <template v-slot:append>
          <div class="pa-2">
            <v-btn @click="logout" block>Logout</v-btn>
          </div>
        </template>
      </v-navigation-drawer>

      <v-app-bar app color="primary" dark>
        <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
        <v-img height="100%" :contain="true" max-width="34" src="/img/deloitte.png"></v-img>
        <v-toolbar-title>Change Impact Assessment</v-toolbar-title>
      </v-app-bar>

      <v-main>
        <v-container fluid>
          <router-view :key="$route.fullPath"></router-view>
        </v-container>
      </v-main>
      <v-footer color="primary" app>
        <span class="white--text">&copy; {{ new Date().getFullYear() }}</span>
      </v-footer>
    </v-container>
  </v-app>
</template>

<script>
export default {
  props: {
    source: String,
  },

  data: () => ({
    drawer: null,
    sites: [],
    homeRoute: "/",
    userManagementRoute: "/user-management",
    settingsRoute: "/settings",
    siteManagementRoute: "/site-management",
    layoutLoaded: false,
  }),

  computed: {},

  created() {
    this.getSites();
  },

  methods: {
    getSites() {
      this.$store
        .dispatch("site/getSites")
        .then((response) => {
          this.sites = response.data;
          this.layoutLoaded = true;
        })
        .catch((error) => {
          console.log(error);
        });
    },

    logout() {
      this.$store.dispatch("logout");
    },

    navigateToOrganogram(siteName) {
      this.$router.push("/sites/" + siteName + "/organogram");
    },

    navigateToHeatmap(siteName) {
      this.$router.push("/sites/" + siteName + "/heatmap");
    },

    navigateToGantt(siteName) {
      this.$router.push("/sites/" + siteName + "/gantt");
    },

    navigateToProjects(siteName) {
      this.$router.push("/sites/" + siteName + "/projects");
    },

    navigateToInitiatives(siteName) {
      this.$router.push("/sites/" + siteName + "/initiatives");
    },

    navigateToChangeJourneys(siteName) {
      this.$router.push("/sites/" + siteName + "/change-journeys");
    },
  },

  watch: {},
};
</script>