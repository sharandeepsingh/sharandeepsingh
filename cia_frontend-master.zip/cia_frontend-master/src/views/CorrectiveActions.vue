<template>
    <h1>Corrective actions</h1>
</template>

<script>
export default {
    data () {
        return {
            
        }
    },

    
}
</script>