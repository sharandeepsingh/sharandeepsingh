<template>
    <h1>Initiatives view</h1>
</template>

<script>
export default {
    data () {
        return {
            
        }
    },

    
}
</script>
