<template>
  <h1>Hello</h1>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'Home',

}
</script>
