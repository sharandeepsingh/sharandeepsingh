<template>
  <loader v-if="!pageLoaded"></loader>
  <v-container v-else fluid>
    <v-row justify="space-between">
      <h1>Active Users:</h1>
      <v-dialog v-model="userDialog" max-width="500px">
        <template v-slot:activator="{ on, attrs }">
          <v-btn color="accent_light" text v-bind="attrs" v-on="on">+ Add a New User</v-btn>
        </template>
        <create-user-form @close="closeCreateDialog" @save="saveUser"></create-user-form>
      </v-dialog>
      <v-card v-for="user in users" :key="user.id" width="100%" height>
        <v-row align="center" class="spacer" no-gutters :style="{ alignContent: 'center' }">
          <v-col cols="1" sm="1" md="1">
            <v-avatar size="36px">
              <v-img v-if="user.avatar"></v-img>
              <v-icon v-else color="blue">{{ `mdi-account` }}</v-icon>
            </v-avatar>
          </v-col>
          <v-col sm="3" md="3">
            <strong v-html="user.name"></strong>
          </v-col>
          <v-col cols="3" sm="2">
            <span>{{ user.email }}</span>
          </v-col>
          <v-col cols="2" sm="1">
            <span v-if="user.is_admin">Admin</span>
            <span v-else>Normal user</span>
          </v-col>
          <v-col cols="3" sm="3">
            <v-dialog v-model="userEditDialog[user.id]" max-width="500px">
              <template v-slot:activator="{ on, attrs }">
                <v-btn color="accent_light" class="mt-1 mb-1" dark v-bind="attrs" v-on="on">Edit</v-btn>
              </template>
              <edit-user-form :user="user" @close="closeEditDialog(user)" @update="updateUser"></edit-user-form>
            </v-dialog>
            <v-btn color="red" class="mt-1 ml-2 mb-1" dark @click="deleteUser(user)">Delete</v-btn>
          </v-col>
        </v-row>
      </v-card>
    </v-row>
  </v-container>
</template>

<script>
import axios from "../services/ApiClient.js";
import CreateUserForm from "../components/users/CreateUserForm.vue";
import EditUserForm from "../components/users/EditUserForm.vue";

export default {
  components: {
    CreateUserForm,
    EditUserForm,
  },

  props: {
    users: {
      type: Array,
      required: true,
    },
  },

  beforeRouteEnter(routeTo, routeFrom, next) {
    axios
      .get("/users")
      .then((response) => {
        routeTo.params.users = response.data;
        next();
      })
      .catch((error) => {
        console.log(
          "There was an error navigating to user management: " + error
        );
        next();
      });
  },

  created() {
    this.pageLoaded = true;
  },

  data() {
    return {
      userDialog: false,
      userEditDialog: {},
      pageLoaded: false,
    };
  },

  methods: {
    closeCreateDialog() {
      this.userDialog = false;
    },

    closeEditDialog(user) {
      this.userEditDialog[user.id] = false;
    },

    saveUser(user) {
      this.pageLoaded = false;

      axios
        .post("/register", {
          username: user.username,
          email: user.email,
          is_admin: user.is_admin,
          password: user.password,
        })
        .then((response) => {
          this.users.push(response.data.user);
          this.closeCreateDialog();
          this.pageLoaded = true;
        })
        .catch((error) => {
          console.log(error);
          this.pageLoaded = true;
        });
    },

    deleteUser(user) {
      this.pageLoaded = false;

      if (confirm("Do you really want to delete this user?")) {
        let index = this.users.indexOf(user);
        axios
          .delete("/users/" + user.id)
          .then(() => {
            this.users.splice(index, 1);
            this.pageLoaded = true;
          })
          .catch((error) => {
            console.log(error);
            this.pageLoaded = true;
          });
      } else {
        this.pageLoaded = true;
      }
    },

    updateUser(user) {
      this.pageLoaded = false;

      axios
        .patch("/users/" + user.id, {
          username: user.name,
          email: user.email,
          is_admin: user.is_admin,
        })
        .then(() => {
          // update the array
          this.closeEditDialog(user);
          this.pageLoaded = true;
        })
        .catch((error) => {
          console.log(error);
          this.pageLoaded = true;
        });
    },
  },
};
</script>