<template>
    <h1>Site Management</h1>
</template>

<script>
export default {
    data () {
        return {
            
        }
    },

    
}
</script>