<template>
  <v-container fluid>
    <loader v-if="!pageLoaded"></loader>
    <v-data-table
      v-else
      :headers="headers"
      :items="projects"
      show-expand
      class="blue-grey lighten-5"
    >
      <template v-slot:top>
        <v-toolbar flat>
          <v-toolbar-title>Projects</v-toolbar-title>
          <v-spacer></v-spacer>
          <v-dialog v-model="dialog" max-width="500px">
            <template v-slot:activator="{ on, attrs }">
              <v-btn
                color="accent_light"
                text
                class="mb-2"
                v-bind="attrs"
                v-on="on"
              >+ Add New Project</v-btn>
            </template>
            <create-project-form @close="close" @save="saveProject"></create-project-form>
          </v-dialog>
        </v-toolbar>
        <v-divider></v-divider>
      </template>
      <template v-slot:item.actions="{ item }">
        <v-dialog v-model="dialogInitiative[item.id]" max-width="500px">
          <template v-slot:activator="{ on, attrs }">
            <v-btn color="accent_light" small dark v-bind="attrs" v-on="on">Add New Initiative</v-btn>
          </template>
          <create-initiative-form :project="item" @save="saveInitiative" @close="close(item.id)"></create-initiative-form>
        </v-dialog>

        <v-btn small dark color="blue" class="ml-4" @click="editProject(item)">Edit Project</v-btn>

        <v-btn small dark class="ml-4" color="red" @click="deleteProject(item)">Delete Project</v-btn>
      </template>
      <template v-slot:no-data>
        <v-btn color="primary" disabled>No Projects Created Yet</v-btn>
      </template>
      <template v-slot:expanded-item="{ headers, item }">
        <td :colspan="headers.length" class="align-content-start">
          <v-simple-table :style="{ tableLayout: 'fixed' }" class="elevation-1">
            <template v-slot:default>
              <thead>
                <tr>
                  <th>Initiative name</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Edit</th>
                  <th>Adjust Impacts</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="initiative in item.initiatives" :key="initiative.id">
                  <td>{{ initiative.name }}</td>
                  <td>{{ initiative.start_date }}</td>
                  <td>{{ initiative.end_date }}</td>
                  <td>
                    <v-dialog v-model="dialogEditInitiative[initiative.id]" max-width="500px">
                      <template v-slot:activator="{ on, attrs }">
                        <v-btn color="accent_light" small dark v-bind="attrs" v-on="on">Edit</v-btn>
                      </template>
                      <edit-initiative-form
                        :initiative="initiative"
                        @save="updateInitiative"
                        @close="close(initiative.id)"
                      ></edit-initiative-form>
                    </v-dialog>
                  </td>
                  <td>
                    <v-btn
                      small
                      dark
                      color="blue"
                      class="ml-2"
                      @click="navigateToImpacts(item, initiative)"
                    >Adjust Impacts</v-btn>
                  </td>
                  <td>
                    <v-btn
                      small
                      dark
                      color="red"
                      class="ml-2"
                      @click="deleteInitiative(item, initiative)"
                    >Delete</v-btn>
                  </td>
                </tr>
              </tbody>
            </template>
          </v-simple-table>
        </td>
      </template>
    </v-data-table>
  </v-container>
</template>

<script>
import axios from "../services/ApiClient.js";
import CreateProjectForm from "../components/projects/CreateProjectForm.vue";
import CreateInitiativeForm from "../components/initiatives/CreateInitiativeForm.vue";
import EditInitiativeForm from "../components/initiatives/EditInitiativeForm.vue";

export default {
  components: {
    CreateProjectForm,
    CreateInitiativeForm,
    EditInitiativeForm,
  },
  props: {
    projects: {
      type: Array,
      required: true,
    },
  },
  beforeRouteEnter(routeTo, routeFrom, next) {
    axios
      .get("/sites/" + routeTo.params.siteId + "/projects-with-initiatives")
      .then((response) => {
        console.log(response);
        routeTo.params.projects = response.data;
        next();
      })
      .catch((error) => {
        console.log("There was an error: " + error);
        next();
      });
  },
  computed: {
    siteId() {
      return this.$route.params.siteId;
    },
  },
  data() {
    return {
      dialog: false,
      dialogInitiative: {},
      dialogEditInitiative: {},
      pageLoaded: true,
      headers: [
        {
          text: "Project Name",
          align: "start",
          sortable: false,
          value: "name",
        },
        { text: "Actions", value: "actions", sortable: false },
      ],
    };
  },

  methods: {
    close(id) {
      this.dialogEditInitiative[id] = false;
      this.dialogInitiative[id] = false;
      this.dialog = false;
    },

    saveProject(projectName) {
      this.pageLoaded = false;
      axios
        .post("/sites/" + this.siteId + "/projects", {
          project_name: projectName,
        })
        .then((response) => {
          console.log(response);
          this.projects.push(response.data.project);
          this.$forceUpdate();
          this.pageLoaded = true;
        })
        .catch((error) => {
          console.log(error);
        });
      // dispatch the axios request and trigger loader
      this.dialog = false;
    },

    saveInitiative(initiative) {
      this.pageLoaded = false;
      // do the axios call
      axios
        .post("/projects/" + initiative.projectId + "/initiatives", {
          name: initiative.initiativeName,
          start_date: initiative.startDate,
          end_date: initiative.endDate,
        })
        .then((response) => {
          this.projects.forEach((key) => {
            if (key.id === initiative.projectId) {
              key.initiatives.push(response.data.initiative);
            }
          });
          this.pageLoaded = true;
        })
        .catch((error) => {
          console.log(error);
          this.pageLoaded = true;
        });
      this.dialogInitiative[initiative.projectId] = false;
    },

    updateInitiative(initiative) {
      this.pageLoaded = false;
      axios
        .patch("/initiatives/" + initiative.id, {
          name: initiative.name,
          start_date: initiative.startDate,
          end_date: initiative.endDate,
        })
        .then(() => {
          // update the item in the array
          this.close(initiative.id);
          this.pageLoaded = true;
        })
        .catch((error) => {
          console.log(error);
        });
    },

    deleteProject(project) {
      this.pageLoaded = false;
      if (
        confirm("Do you really want to delete project: " + project.name + "?")
      ) {
        let index = this.projects.indexOf(project);
        axios
          .delete("/projects/" + project.id)
          .then(() => {
            this.projects.splice(index, 1);
            this.$forceUpdate();
            this.pageLoaded = true;
          })
          .catch((error) => {
            console.log(error);
          });
        this.pageLoaded = true;
      } else {
        this.pageLoaded = true;
      }
    },

    deleteInitiative(project, initiative) {
      this.pageLoaded = false;
      if (confirm("Do you really want to delete this initiative?")) {
        axios
          .delete("/initiatives/" + initiative.id)
          .then(() => {
            let index = project.initiatives.indexOf(initiative);
            project.initiatives.splice(index, 1);
            this.pageLoaded = true;
          })
          .catch((error) => {
            console.log(error);
            this.pageLoaded = true;
          });
      } else {
        this.pageLoaded = true;
      }
    },

    navigateToImpacts(project, initiative) {
      this.$router.push({
        name: "impact-inputs",
        params: {
          passedProjectId: project.id,
          passedInitiativeId: initiative.id,
        },
      });
    },
  },
};
</script>

<style scoped>
</style>