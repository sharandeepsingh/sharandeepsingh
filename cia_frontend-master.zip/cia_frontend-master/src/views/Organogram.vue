<template>
  <loader v-if="!pageLoaded"></loader>
  <v-container v-else class="d-flex justify-center full-width fill-height" fluid>
    <v-row>
      <v-spacer></v-spacer>
      <v-col>
        <SiteCard :siteName="siteName" :employeeCount="employeeCount" @addCommunity="addCommunity" />
      </v-col>
      <v-spacer></v-spacer>
    </v-row>

    <v-row class="mt-4">
      <v-col v-for="community in communities" :key="community.id">
        <NewCommunityCard
          v-if="community.new"
          @cancel="cancelCreateCommunity"
          @save="saveCommunity"
        />
        <CommunityCard v-else :community="community" @delete="deleteCommunity" />
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import SiteCard from "../components/organogram/SiteCard.vue";
import CommunityCard from "../components/organogram/CommunityCard.vue";
import NewCommunityCard from "../components/organogram/NewCommunityCard.vue";

export default {
  components: {
    SiteCard,
    CommunityCard,
    NewCommunityCard,
  },
  data() {
    return {
      pageLoaded: false,
      siteId: 0,
      siteName: "",
      employeeCount: 0,
      communities: [[]],
      newCommunityCardActive: false,
    };
  },

  mounted() {
    this.getSiteInfo();
    this.getCommunities();
    this.getPersonas();
  },

  methods: {
    getPersonas() {
      this.$store
        .dispatch("getPersonas", this.siteId)
        .then(() => {
          console.log("Personas retrieved..");
        })
        .catch((error) => {
          console.log("Persona retrieval error: " + error);
        });
    },

    getSiteInfo() {
      this.siteId = this.$route.params.siteId;
      this.siteName = this.$store.state.site.currentSite.data.name;
    },

    getCommunities() {
      this.pageLoaded = false;
      this.communitues = [];
      this.$store.dispatch("getCommunities", this.siteId).then((data) => {
        this.communities = data;
        this.updateEmployeeCount();
        this.pageLoaded = true;
      });
    },

    updateEmployeeCount() {
      this.employeeCount = 0;
      this.communities.forEach((community) => {
        community.personas.forEach((persona) => {
          this.employeeCount += persona.pivot.member_count;
        });
      });
    },

    addCommunity() {
      if (this.newCommunityCardActive) {
        // issue snackbar
      } else {
        this.communities.push({
          name: "Enter Name",
          new: true,
          members: [],
        });
        this.newCommunityCardActive = true;
      }
    },

    saveCommunity(community) {
      this.pageLoaded = false;
      community.siteId = this.siteId;
      this.$store
        .dispatch("community/saveCommunity", community)
        .then(() => {
          this.newCommunityName = "";
          this.newCommunityIE = false;
          this.newCommunityCardActive = false;
          this.getCommunities();
        })
        .catch((error) => {
          throw error;
        });
      this.pageLoaded = true;
    },

    deleteCommunity(community) {
      this.pageLoaded = false;
      this.$store.dispatch("community/deleteCommunity", community).then(() => {
        this.getCommunities();
        //this.organogramGroups.splice(stakeholderGroupId-1, 1)
      });
      this.pageLoaded = true;
    },

    cancelCreateCommunity() {
      this.communities.pop();
      this.newCommunityCardActive = false;
    },
  },
};
</script>

<style scoped>
.cardwidth {
  width: 200px;
}
</style>
