<template>
  <v-col cols="12" sm="8" md="4">
    <div class="mx-2">
      <h1 class="white--text display-1 mb-4">Login</h1>

      <form @submit.prevent="login" ref="form" lazy-validation>
        <v-text-field
          v-model="email"
          ref="email"
          :error-messages="emailErrors"
          @blur="$v.email.$touch()"
          label="Email"
          color="white"
          required
          dark
        ></v-text-field>
        <v-text-field
          v-model="password"
          :error-messages="passwordErrors"
          @blur="$v.password.$touch()"
          label="Password"
          type="password"
          color="white"
          required
          dark
        ></v-text-field>

        <router-link to="/" class="white--text" dark>Forgot password?</router-link>

        <v-btn
          block
          depressed
          :loading="loading"
          :disabled="loading"
          type="submit"
          class="mt-6"
          :class="isValid ? 'white indigo--text text--darken-2' : 'transparent-btn white--text'"
        >Login</v-btn>
      </form>
    </div>
  </v-col>
</template>

<script>
import { validationMixin } from "vuelidate";
import { required, minLength, email } from "vuelidate/lib/validators";

export default {
  mixins: [validationMixin],

  data() {
    return {
      name: "",
      email: "",
      loader: null,
      loading: false,
      password: "",
    };
  },

  mounted() {
    this.$nextTick(this.$refs.email.focus);
  },

  computed: {
    isValid() {
      return (
        !!this.email &&
        !!this.password &&
        !this.emailErrors.length &&
        !this.passwordErrors.length
      );
    },

    emailErrors() {
      const errors = [];
      if (!this.$v.email.$dirty) return errors;
      !this.$v.email.email && errors.push("Must be valid email");
      !this.$v.email.required && errors.push("Email is required");
      return errors;
    },

    passwordErrors() {
      const errors = [];
      if (!this.$v.password.$dirty) return errors;
      !this.$v.password.minLength &&
        errors.push("Password must be at least 6 characters long");
      !this.$v.password.required && errors.push("Password is required");
      return errors;
    },
  },

  watch: {
    loader() {
      const l = this.loader;
      this[l] = !this[l];
      this.loader = null;
    },
  },

  validations: {
    email: { required, email },
    password: {
      required,
      minLength: minLength(6),
    },
  },

  methods: {
    login() {
      if (this.$v.$invalid) return;

      this.loader = "loading";

      this.$store
        .dispatch("login", {
          email: this.email,
          password: this.password,
        })
        .then((data) => {
          this.loader = "loading";
          console.log(data);
          this.$router.push("/");
        })
        .catch((error) => {
          console.log(error);

          this.loader = "loading";
        });
    },
  },
};
</script>
