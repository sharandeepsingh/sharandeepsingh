<template>
  <h1>Change Journeys</h1>
</template>

<script>
export default {
  props: {
    changeJourneys: {
      type: Array,
      required: true,
    },
  },

  components: {},

  beforeRouteEnter(routeTo, routeFrom, next) {
    axios
      .get("/sites/" + routeTo.params.siteId + "/change-journeys")
      .then((response) => {
        console.log(response);
        routeTo.params.changeJourneys = response.data;
        next();
      });
  },

  data() {
    return {};
  },

  methods: {},
};
</script>

<style>
</style>