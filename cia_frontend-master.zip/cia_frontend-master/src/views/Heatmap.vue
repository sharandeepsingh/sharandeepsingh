<template>
  <loader v-if="!pageLoaded"></loader>
  <v-container v-else fluid>
    <!-- <div class="flex flex-row justify-around items-center bg-gray-200 border-gray-600 border-2 rounded"> -->
    <v-row>
      <v-col :style="{ 'width': '200px' }">
        <v-card></v-card>
      </v-col>
      <v-col>
        <v-select
          class="ml-4"
          v-model="selectedProjectsIds"
          :items="projects"
          item-text="name"
          item-value="id"
          chips
          :menu-props="{ maxHeight: '400' }"
          label="Select Projects"
          multiple
          hint="Select projects to overlay"
          persistent-hint
        >
          <v-list-item slot="prepend-item" ripple @click="toggle">
            <v-list-item-action>
              <v-icon :color="selectedInitiativesIds.length > 0 ? 'indigo darken-4' : ''">{{ icon }}</v-icon>
            </v-list-item-action>
            <v-list-item-title>Select All</v-list-item-title>
          </v-list-item>
          <v-divider slot="prepend-item" class="mt-2" />
        </v-select>
      </v-col>

      <v-col>
        <v-select
          class="ml-4"
          v-model="selectedInitiativesIds"
          :items="initiatives"
          item-text="name"
          item-value="id"
          chips
          :menu-props="{ maxHeight: '400' }"
          label="Select Initiatives"
          multiple
          hint="Select individual initiatives to overlay"
          persistent-hint
        ></v-select>
      </v-col>

      <v-col>
        <div class="flex ml-12 mt-6">
          <v-btn color="accent_light" large dark @click="navigateToEdit">Edit Impacts</v-btn>
        </div>
      </v-col>

      <v-spacer></v-spacer>
    </v-row>

    <v-row>
      <v-spacer></v-spacer>
      <v-col cols="auto">
        <HeatmapTool
          :changeAspects="changeAspects"
          :stakeholderGroups="stakeholderGroups"
          :impacts="impacts"
          :expandedStakeholderGroup="expandedStakeholderGroup"
          @expandStakeholderGroup="expandStakeholderGroup"
        />
      </v-col>
      <v-spacer></v-spacer>
    </v-row>
  </v-container>
</template>

<script>
import HeatmapTool from "../components/HeatmapTool.vue";
import axios from "../services/ApiClient.js";
import HeatmapHelper from "../components/heatmap/helpers/HeatmapHelper.js";

export default {
  props: {},

  components: {
    HeatmapTool,
  },

  data: () => ({
    impactArray: ["Low", "Medium", "High"],
    impacts: {},
    projects: [],
    selectedProjectsIds: [],
    selectedInitiativesIds: [],
    stakeholderGroups: [],
    changeAspects: [],
    pageLoaded: false,
    expandedStakeholderGroup: {},
  }),

  created: function () {
    this.getProjects();
    this.getStakeholderGroupsWithRoles();
  },

  computed: {
    selectAllProjects() {
      return this.selectedProjectsIds.length === this.projects.length;
    },

    selectSomeProjects() {
      return this.selectedProjectsIds.length > 0 && !this.selectAllProjects;
    },

    icon() {
      if (this.selectAllProjects) return "mdi-close-box";
      if (this.selectSomeProjects) return "mdi-minus-box";
      return "mdi-checkbox-blank-outline";
    },

    siteId() {
      return this.$route.params.siteId;
    },

    initiatives() {
      let arr = [];
      this.selectedProjects.forEach((project) => {
        project.initiatives.forEach((initiative) => {
          arr.push(initiative);
        });
      });

      return arr;
    },

    selectedProjects() {
      return this.projects.filter((project) => {
        return !(this.selectedProjectsIds.indexOf(project.id) === -1);
      });
    },
  },

  methods: {
    toggle() {
      this.$nextTick(() => {
        if (this.selectAllProjects) {
          this.selectedProjectsIds = [];
        } else {
          this.selectedProjectsIds = this.projects.slice().map((a) => a.id);
        }
      });
    },

    getStakeholderGroupsWithRoles() {
      axios
        .get("/sites/" + this.siteId + "/stakeholder-groups-with-roles")
        .then((response) => {
          this.stakeholderGroups = response.data;
          for (let i = 0; i < this.stakeholderGroups.length; i++) {
            this.stakeholderGroups[i].color = "primary";
          }
          this.getChangeAspects();
        });
    },

    getChangeAspects() {
      axios.get("/change-aspects").then((response) => {
        this.changeAspects = response.data;
      });
    },

    getProjects() {
      axios
        .get("/sites/" + this.siteId + "/projects-with-initiatives")
        .then((response) => {
          this.projects = response.data;
          this.pageLoaded = true;
          this.getImpacts();
        });
    },

    getImpacts() {
      this.pageLoaded = false;
      if (!this.selectedInitiativesIds.length == 0) {
        // the user has selected individual initiatives
        let initiativeIds = this.selectedInitiativesIds.map((a) => a);
        axios
          .get("/sites/" + this.siteId + "/multiple-initiatives/impacts", {
            params: {
              initiative_ids: initiativeIds,
            },
          })
          .then((response) => {
            this.impacts = response.data;
            this.pageLoaded = true;
          });
      } else if (!this.selectedProjectsIds.length == 0) {
        let projectIds = this.selectedProjects.map((a) => a.id);
        axios
          .get("/sites/" + this.siteId + "/multiple-projects/impacts", {
            params: {
              project_ids: projectIds,
            },
          })
          .then((response) => {
            this.impacts = response.data;
            this.pageLoaded = true;
          });
      } else {
        this.generateEmptyImpactArray();
        this.pageLoaded = true;
      }
    },

    expandStakeholderGroup(stakeholderGroup) {
      this.expandedStakeholderGroup = stakeholderGroup;

      this.stakeholderGroups = HeatmapHelper.expandStakeholderGroup(
        this.stakeholderGroups,
        stakeholderGroup
      );
    },

    generateEmptyImpactArray() {
      this.impacts = HeatmapHelper.generateEmptyImpactArray(
        this.stakeholderGroups,
        this.changeAspects
      );
    },

    navigateToEdit() {
      this.$router.push("/sites/" + this.siteId + "/impact-inputs");
    },
  },

  watch: {
    selectedProjects() {
      this.getImpacts();
    },
    changeAspects() {
      this.getImpacts();
    },
    stakeholderGroups() {
      this.getImpacts();
    },
    selectedInitiativesIds() {
      this.getImpacts();
    },
    selectedProjectsIds(val) {
      if (val.length == 0) {
        this.selectedInitiativesIds = [];
      }
    },
  },
};
</script>
