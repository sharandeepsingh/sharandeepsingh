<template>
  <loader v-if="!pageLoaded"></loader>
  <v-container v-else fluid>
    <v-row>
      <v-col :style="{ 'width': '200px' }">
        <v-card></v-card>
      </v-col>
      <v-col>
        <v-select
          class="ml-4"
          v-model="selectedProjectId"
          :items="projects"
          item-text="name"
          item-value="id"
          :menu-props="{ maxHeight: '400' }"
          label="Select Project"
          hint="Select projects to overlay"
          persistent-hint
        ></v-select>
      </v-col>

      <v-col>
        <v-select
          class="ml-4"
          v-model="selectedInitiativeId"
          :items="initiatives"
          item-text="name"
          item-value="id"
          :menu-props="{ maxHeight: '400' }"
          label="Select Initiative"
          hint="Select individual initiatives to overlay"
          persistent-hint
        ></v-select>
      </v-col>

      <v-col>
        <div class="flex ml-12 mt-6">
          <v-btn color="accent_light" large dark @click="saveImpacts">Save Impacts</v-btn>
        </div>
      </v-col>

      <v-spacer></v-spacer>
    </v-row>

    <v-row>
      <v-spacer></v-spacer>
      <impact-selector-button
        impactLevel="H"
        :selectedImpactLevel="selectedImpactLevel"
        @clicked="selectImpactLevel(3)"
      ></impact-selector-button>
      <impact-selector-button
        impactLevel="M"
        :selectedImpactLevel="selectedImpactLevel"
        @clicked="selectImpactLevel(2)"
      ></impact-selector-button>
      <impact-selector-button
        impactLevel="L"
        :selectedImpactLevel="selectedImpactLevel"
        @clicked="selectImpactLevel(1)"
      ></impact-selector-button>
      <impact-selector-button
        impactLevel="N"
        :selectedImpactLevel="selectedImpactLevel"
        @clicked="selectImpactLevel(0)"
      ></impact-selector-button>
      <v-spacer></v-spacer>
    </v-row>

    <v-row>
      <v-spacer></v-spacer>
      <v-col cols="auto">
        <impact-input-tool
          :stakeholderGroups="stakeholderGroups"
          :impacts="impacts"
          :changeAspects="changeAspects"
          :expandedStakeholderGroup="expandedStakeholderGroup"
          :selectedImpactLevel="selectedImpactLevel"
          @impactInputClicked="updateImpact"
          @expandStakeholderGroup="expandStakeholderGroup"
        ></impact-input-tool>
      </v-col>
      <v-spacer></v-spacer>
    </v-row>

    <v-snackbar v-model="snackbar" :timeout="snackbarTimeout" :color="snackbarColor">
      {{ snackbarMessage }}
      <template v-slot:action="{ attrs }">
        <v-btn color="grey lighten-3" text v-bind="attrs" @click="snackbar = false">Close</v-btn>
      </template>
    </v-snackbar>
  </v-container>
</template>

<script>
import ImpactInputTool from "../components/ImpactInputTool.vue";
import axios from "../services/ApiClient.js";
import HeatmapHelper from "../components/heatmap/helpers/HeatmapHelper.js";
import ImpactSelectorButton from "../components/impactinput/ImpactSelectorButton.vue";

export default {
  components: {
    ImpactInputTool,
    ImpactSelectorButton,
  },
  props: {
    passedProjectId: {
      type: Number,
    },
    passedInitiativeId: {
      type: Number,
    },
  },
  data() {
    return {
      pageLoaded: true,
      impactArray: ["Low", "Medium", "High"],
      impacts: {},
      projects: [],
      selectedProjectId: null,
      selectedInitiativeId: [],
      stakeholderGroups: [],
      changeAspects: [],
      expandedStakeholderGroup: {},
      selectedImpactLevel: 0,
      snackbar: false,
      snackbarMessage: "",
      snackbarTimeout: 2000,
      snackbarColor: "accent_light",
    };
  },

  created: function () {
    // check if the user is navigating from the edit projects page
    if (this.passedProjectId != null) {
      this.selectedProjectId = this.passedProjectId;
    }
    if (this.passedInitiativeId != null) {
      this.selectedInitiativeId = this.passedInitiativeId;
    }
    this.getProjects();
    this.getStakeholderGroupsWithRoles();
  },

  computed: {
    siteId() {
      return this.$route.params.siteId;
    },

    initiatives() {
      let arr = [];
      this.selectedProject.forEach((project) => {
        project.initiatives.forEach((initiative) => {
          arr.push(initiative);
        });
      });

      return arr;
    },

    selectedProject() {
      return this.projects.filter((project) => {
        return this.selectedProjectId == project.id;
      });
    },

    selectedInitiative() {
      return this.initiatives.filter((initiative) => {
        return this.selectedInitiativeId == initiative.id;
      });
    },
  },

  methods: {
    getStakeholderGroupsWithRoles() {
      axios
        .get("/sites/" + this.siteId + "/stakeholder-groups-with-roles")
        .then((response) => {
          this.stakeholderGroups = response.data;
          for (let i = 0; i < this.stakeholderGroups.length; i++) {
            this.stakeholderGroups[i].color = "primary";
          }
          this.getChangeAspects();
        });
    },

    getChangeAspects() {
      axios.get("/change-aspects").then((response) => {
        this.changeAspects = response.data;
        this.getImpacts();
      });
    },

    getProjects() {
      axios
        .get("/sites/" + this.siteId + "/projects-with-initiatives")
        .then((response) => {
          this.projects = response.data;

          this.pageLoaded = true;
        });
    },

    getImpacts() {
      if (!this.selectedInitiative.length == 0) {
        axios
          .get("/initiatives/" + this.selectedInitiative[0].id + "/impacts")
          .then((response) => {
            this.impacts = response.data;
          });
      } else {
        this.generateEmptyImpactArray();
      }
    },

    expandStakeholderGroup(stakeholderGroup) {
      this.expandedStakeholderGroup = stakeholderGroup;

      this.stakeholderGroups = HeatmapHelper.expandStakeholderGroup(
        this.stakeholderGroups,
        stakeholderGroup
      );
    },

    generateEmptyImpactArray() {
      this.impacts = HeatmapHelper.generateEmptyImpactArray(
        this.stakeholderGroups,
        this.changeAspects
      );
    },

    selectImpactLevel(level) {
      this.selectedImpactLevel = level;
    },

    updateImpact(...args) {
      let [stakeholderGroup, changeAspect] = args;
      this.impacts[this.expandedStakeholderGroup.id][changeAspect.id][
        stakeholderGroup.id
      ] = this.selectedImpactLevel;
    },

    saveImpacts() {
      let obj = {};
      // prepare the impacts array
      for (const sgKey in this.impacts) {
        // let stakeholderGroup = this.impacts[sgKey];
        for (const caKey in this.impacts[sgKey]) {
          // let changeAspect = this.impacts[sgKey][caKey];
          for (const srKey in this.impacts[sgKey][caKey]) {
            // let stakeholderRole = this.impacts[sgKey][caKey][srKey];
            if (!obj[srKey]) {
              obj[srKey] = {};
            }
            if (!obj[srKey][caKey]) {
              obj[srKey][caKey] = {};
            }
          }
        }
      }

      // console.log(obj);

      for (const sgKey in this.impacts) {
        // let stakeholderGroup = this.impacts[sgKey];
        for (const caKey in this.impacts[sgKey]) {
          // let changeAspect = this.impacts[sgKey][caKey];
          for (const srKey in this.impacts[sgKey][caKey]) {
            obj[srKey][caKey] = this.impacts[sgKey][caKey][srKey];
          }
        }
      }

      //call the axios post function
      axios
        .post("/impacts", {
          initiative_id: this.selectedInitiative[0].id,
          impacts: obj,
        })
        .then(() => {
          this.snackbarColor = "accent_light";
          this.snackbarMessage = "Impacts saved.";
          this.snackbar = true;
        })
        .catch((error) => {
          this.snackbarColor = "red";
          this.snackbarMessage = "There was an error: " + error;
          this.snackbar = true;
        });
    },
  },

  watch: {
    selectedInitiative() {
      this.getImpacts();
    },
  },
};
</script>

<style>
</style>