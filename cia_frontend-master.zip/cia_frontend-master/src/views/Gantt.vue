<template>
  <v-container>
    <GanttTool />
  </v-container>
</template>

<script>
import GanttTool from "../components/GanttTool.vue";
export default {
  components: {
    GanttTool,
  },

  data() {
    return {};
  },
};
</script>
