<template>
  <component v-bind:is="layout"></component>
</template>

<script>
import BaselineLayout from './views/layouts/BaselineLayout.vue'
import AuthLayout from './views/layouts/AuthLayout.vue'
import { mapGetters } from 'vuex'

export default {
  name: 'App',

  components: {
    'auth-layout': AuthLayout,
    'baseline-layout': BaselineLayout,
  },

  mounted () {

  },

  computed: {
    ...mapGetters([
      'layout',
      'onlineStatus'
    ])
  },

  methods: {
    setOnlineStatus () {
      this.$store.commit('SET_ONLINE_STATUS', {
        onlineStatus: navigator.online || false
      })
    }
  }
}
</script>