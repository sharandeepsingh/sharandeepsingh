import Vue from 'vue'
import Vuex from 'vuex'
import axios from '../services/ApiClient'
import * as site from './modules/site.js'
import * as community from './modules/community.js'
import * as stakeholdergroup from './modules/stakeholdergroup.js'
import * as changeaspect from './modules/changeaspect.js'

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    site,
    stakeholdergroup,
    changeaspect,
    community
  },

  state: {
    user: null,
    layout: 'auth-layout',
    onlineStatus: true,
    personas: []
  },
  mutations: {
    CLEAR_USER_DATA(state) {
      localStorage.removeItem('user')
      state.overlay = false
      location.reload()
    },

    SET_USER_DATA(state, payload) {
      state.user = payload
      localStorage.setItem('user', JSON.stringify(payload))
      axios.defaults.headers.common.Authorization = `Bearer ${payload.token}`
    },

    SET_LAYOUT(state, payload) {
      state.layout = payload
    },

    SET_ONLINE_STATUS(state, payload) {
      state.onlineStatus = payload.onlineStatus
    },

    SET_PERSONAS(state, payload) {
      state.personas = payload
    }
  },
  getters: {
    isAuthenticated: state => !!state.user,
    user: state => state.user.user,
    layout: state => state.layout,
    onlineStatus: state => state.onlineStatus,
    personas: state => state.personas,
  },

  actions: {
    getPersonas({
      commit
    }) {
      return axios.get('/personas')
        .then(({
          data
        }) => {
          console.log('personas')
          console.log(data)
          commit('SET_PERSONAS', data)
          return data
        })
    },

    getCommunities({
      commit
    }, siteId) {
      return axios.get('/sites/' + siteId + '/communities-with-personas')
        .then(({
          data
        }) => {
          console.log(commit)
          return data
        })
        .catch((error) => {
          throw error
        })
    },

    login({
      commit
    }, credentials) {
      return axios.post('/login', credentials)
        .then(({
          data
        }) => {
          commit('SET_USER_DATA', data)
          return data.user
        })
        .catch((error) => {
          commit('SET_SNACKBAR', {
            color: 'red lighten-1',
            message: 'Your credentials are incorrect. Please try again.',
            timeout: 3000,
            status: true
          })
          throw error
        })
    },

    logout({
      commit
    }) {
      return axios
        .post('/logout')
        .then(({
          data
        }) => {
          console.log(data)
          commit('CLEAR_USER_DATA')
        })
    },

    // register({
    //   commit
    // }, credentials) {
    //   return axios
    //     .post('/register', credentials)
    //     .then(({
    //       data
    //     }) => {
    //       console.log('register')
    //       // commit('SET_USER_DATA', data)
    //     })
    //     .catch((error) => {
    //       throw error
    //     })
    // }
  }
})