import ChangeAspectService from '../../services/ChangeAspectService.js'

export const namespaced = true

export const state = {

}

export const mutations = {

}

export const actions = {
    getChangeAspects() {
        ChangeAspectService.getChangeAspects()
            .then((response) => {
                return response.data
            })
            .catch((error) => {
                // add notification
                throw error
            })
    }
}