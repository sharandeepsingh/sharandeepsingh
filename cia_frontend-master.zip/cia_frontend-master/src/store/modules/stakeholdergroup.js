import StakeholderGroupService from '../../services/StakeholderGroupService.js'

export const namespaced = true

export const state = {

}

export const mutations = {

}

export const actions = {
    getSiteStakeholderGroups({
        commit
    }, siteId) {
        console.log(commit)
        StakeholderGroupService.getSiteStakeholderGroups(siteId)
            .then((response) => {
                return response.data.stakeholderGroup
            })
            .catch((error) => {
                // add notification
                throw error
            })
    },

    getSiteStakeholderGroupsWithRoles({
        commit
    }, siteId) {
        console.log(commit)
        StakeholderGroupService.getSiteStakeholderGroupsWithRoles(siteId)
            .then((response) => {
                console.log(response)
                return response.data
            })
            .catch((error) => {
                // add notification
                throw error
            })
    },

    saveStakeholderGroup({
        commit
    }, stakeholderGroup) {
        console.log(commit)
        StakeholderGroupService.saveStakeholderGroup(stakeholderGroup)
            .then(({
                data
            }) => {
                return data.stakeholderGroup
            })
            .catch((error) => {
                throw error
            })
    },

    deleteStakeholderGroup({
        commit
    }, stakeholderGroup) {
        console.log(commit)
        StakeholderGroupService.deleteStakeholderGroup(stakeholderGroup)
            .then((data) => {
                return data
            })
            .catch((error) => {
                throw error
            })
    }
}