import UserService from '../../services/UserService.js'

export const namespaced = true

export const state = {
    user: null,
    localToken: ''
}

export const mutations = {
    CLEAR_USER_DATA() {
        localStorage.removeItem('user')
        localStorage.removeItem('token')
        location.reload()
    },

    SET_USER_DATA_FROM_LOGIN(state, response) {
        state.user = response.data
        localStorage.setItem('user', response.data)
        localStorage.setItem('token', response.data.token)
        //axios.defaults.headers.common.Authorization = `Bearer ${response.data.token}`
    },

    SET_USER_DATA(state, userData) {
        state.user = userData
        localStorage.setItem('user', userData)
        localStorage.setItem('token', userData.token)
    }
}

export const actions = {
    login({
        commit
    }, credentials) {
        return UserService.login(credentials)
            .then((response) => {
                commit('SET_USER_DATA_FROM_LOGIN', response)
                return response.user
            })
            .catch((error) => {
                // add notification
                throw error
            })
    },

    logout({
        commit
    }) {
        return UserService.logout()
            .then(() => {
                commit('CLEAR_USER_DATA')
            })
    },

    setUserData({
        commit
    }, userData) {
        commit('SET_USER_DATA', userData)
    }
}

export const getters = {
    user: state => state.user.user
}