import SiteService from '../../services/SiteService.js'

export const namespaced = true

export const state = {
    sites: [],
    currentSite: {}
}

export const mutations = {
    SET_SITES_DATA(state, sites) {
        state.sites = sites
    },
    SET_SITE_DATA(state, site) {
        state.currentSite = site
    }
}

export const actions = {
    getSites({
        commit,
        state
    }) {
        if (typeof state.sites === undefined || state.sites.length == 0) {
            return SiteService.getSites()
                .then((response) => {
                    commit('SET_SITES_DATA', response)
                    return response
                }).catch((error) => {
                    // add notification
                    throw error
                })
        }
    },

    getSite({
        commit,
    }, siteId) {

        return SiteService.getSite(siteId)
            .then((response) => {
                commit('SET_SITE_DATA', response)
                return response
            })
            .catch((error) => {
                // add notification + snackbar
                throw error
            })
    }
}

export const getters = {

}