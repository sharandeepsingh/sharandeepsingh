import CommunityService from '../../services/CommunityService.js'

export const namespaced = true

export const state = {

}

export const mutations = {

}

export const actions = {
    getSiteCommunities({
        commit
    }, siteId) {
        console.log(commit)
        CommunityService.getSiteCommunities(siteId)
            .then((response) => {
                return response.data.community
            })
            .catch((error) => {
                // add notification
                throw error
            })
    },

    getSiteCommunitiesWithMembers({
        commit
    }, siteId) {
        console.log(commit)
        CommunityService.getSiteCommunitiesWithMembers(siteId)
            .then((response) => {
                console.log(response)
                return response.data
            })
            .catch((error) => {
                // add notification
                throw error
            })
    },

    saveCommunity({
        commit
    }, community) {
        console.log(commit)
        CommunityService.saveCommunity(community)
            .then(({
                data
            }) => {
                return data.community
            })
            .catch((error) => {
                throw error
            })
    },

    deleteCommunity({
        commit
    }, community) {
        console.log(commit)
        CommunityService.deleteCommunity(community)
            .then((data) => {
                return data
            })
            .catch((error) => {
                throw error
            })
    }
}